# WorldMonitor.app — Análise Técnica Profunda

> Documento gerado em: 01 Mar 2026  
> Fonte primária: https://worldmonitor.app | https://github.com/koala73/worldmonitor  
> Versão analisada: **v2.5.21**

---

## Índice

1. [Visão Geral do Projeto](#1-visão-geral-do-projeto)
2. [Arquitetura Técnica](#2-arquitetura-técnica)
3. [Repositório GitHub](#3-repositório-github)
4. [Funcionalidades Principais](#4-funcionalidades-principais)
5. [Fontes de Dados e APIs](#5-fontes-de-dados-e-apis)
6. [Design e UX](#6-design-e-ux)
7. [Variantes da Plataforma](#7-variantes-da-plataforma)
8. [Deployment e Infraestrutura](#8-deployment-e-infraestrutura)
9. [Inteligência Artificial](#9-inteligência-artificial)
10. [Aplicativo Desktop (Tauri)](#10-aplicativo-desktop-tauri)
11. [Considerações de Segurança e Privacidade](#11-considerações-de-segurança-e-privacidade)
12. [Estado Atual e Comunidade](#12-estado-atual-e-comunidade)

---

## 1. Visão Geral do Projeto

**WorldMonitor.app** é um dashboard de inteligência global em tempo real — open source, gratuito e com licença MIT. Foi criado por **Elie Habib**, cofundador do Anghami (plataforma de streaming de música do Oriente Médio), como um projeto pessoal de fim de semana para acompanhar eventos globais sem depender de TV. O projeto viralizou no GitHub, atingindo **10.000+ estrelas** logo após o lançamento público em fevereiro de 2026.

**Missão**: Agregar inteligência geopolítica, militar, econômica e de segurança de 100+ fontes em uma única interface operacional — comparável a um "CNN war room × Bloomberg Terminal × stack OSINT", mas 100% gratuito.

**GitHub**: https://github.com/koala73/worldmonitor  
**Autor principal**: @koala73 (Elie Habib, @eliehabib no Twitter/X)  
**Licença**: MIT  
**Versão atual**: v2.5.21 (lançada em 01/03/2026)  
**Número de workflows CI rodados**: 395+ (ativo e crescendo)

---

## 2. Arquitetura Técnica

### 2.1 Stack Tecnológico

| Camada | Tecnologia |
|--------|-----------|
| **Frontend** | TypeScript + Vite (SPA vanilla — sem framework como React/Vue) |
| **Mapa 2D** | MapLibre GL JS |
| **Mapa 3D** | deck.gl (WebGL, renderização 60fps) |
| **Charts/Timelines** | D3.js |
| **ML no browser** | Transformers.js (ONNX — NER, sentiment, T5 summarization) |
| **Geo clustering** | Supercluster |
| **Geo hex grid** | H3 (Uber) |
| **PWA/Service Worker** | Workbox |
| **Contratos API** | Protocol Buffers (sebuf — framework proto-first HTTP) |
| **Testes E2E** | Playwright |
| **Desktop** | Tauri (Rust + WebView — cross-platform: macOS, Windows, Linux) |
| **Build tool** | Vite + Rollup |
| **Tipagem** | TypeScript estrito |

### 2.2 Stack de Backend / Infraestrutura

| Camada | Tecnologia |
|--------|-----------|
| **API Edge Functions** | Vercel Edge Functions (Node.js runtime) |
| **WebSocket Relay** | Railway (Node.js container persistente) |
| **Cache** | Redis via Upstash (TTL variável por endpoint) |
| **CDN/Proxy** | Cloudflare (proxy.worldmonitor.app — edge caching adicional) |
| **Análise de erros** | Sentry |
| **Banco de dados** | Convex (para "register interest" / features sociais) |
| **Protocolo WS** | AIS via WebSocket, OpenSky Network via WebSocket relay |

### 2.3 Modelo de Comunicação

```
Browser
  │
  ├── GET /api/{domain}/v1/{rpc}  ──→  Vercel Edge Functions (serverless)
  │                                            │
  │                                            ├──→ Upstash Redis (cache)
  │                                            ├──→ APIs externas (ACLED, GDELT, etc.)
  │                                            └──→ Railway WS Relay (proxy)
  │
  ├── WebSocket  ──────────────────→  Railway Relay (persistente)
  │                                            │
  │                                            ├──→ OpenSky Network (ADS-B)
  │                                            ├──→ AIS Stream (navios)
  │                                            ├──→ Telegram MTProto (27 canais)
  │                                            └──→ OREF Israel sirens
  │
  └── localStorage/IndexedDB  ──→  Estado local (tema, paineis, histórico)
```

### 2.4 Contracts de API (Proto-First)

O projeto usa **sebuf** — um framework que gera TypeScript clients, server stubs e documentação OpenAPI 3.1.0 a partir de arquivos `.proto`. Isso garante contratos tipados sem drift entre frontend e backend.

**20 domínios de serviço**:
`aviation` · `climate` · `conflict` · `cyber` · `displacement` · `economic` · `infrastructure` · `intelligence` · `maritime` · `market` · `military` · `news` · `prediction` · `research` · `seismology` · `supply-chain` · `trade` · `unrest` · `wildfire` · `(outros)`

Todos os endpoints são **POST/GET estáticos** em `/api/{domain}/v1/{rpc}`, com CORS enforcement e error boundary.

### 2.5 Sistema de Cache

| Tipo de dado | TTL | Estratégia |
|-------------|-----|-----------|
| Fontes RSS/notícias | 20 min (aumentado de 10) | NetworkOnly (sempre fresco) |
| Snapshots AIS/voos militares | 10s | Redis + edge |
| Sumarizações LLM | 24h | Redis dedup por hash |
| Classificações LLM por headline | 24h | Redis por headline hash |
| Tiles de mapa offline | 30 dias | CacheFirst (até 500 tiles) |
| Fontes/assets estáticos | 1 ano (imutável) | Cache agressivo |
| Imagens | 7 dias | StaleWhileRevalidate |

---

## 3. Repositório GitHub

**URL**: https://github.com/koala73/worldmonitor  
**Criado em**: Janeiro 2026  
**Estrelas**: 10.000+ (viralizou em fev/2026)

### 3.1 Estrutura de Diretórios (inferida)

```
worldmonitor/
├── index.html               # SPA entry point
├── package.json             # Dependências npm + scripts
├── tsconfig.json            # Configuração TypeScript
├── vite.config.ts           # Vite + sebufApiPlugin (dev server)
├── CLAUDE.md                # Guia para desenvolvedores que usam Claude AI
├── README.md                # Documentação completa (~10.000 linhas)
├── Makefile                 # `buf generate` para gerar código proto
├── railpack.json            # Configuração do Railway relay (substituiu nixpacks.toml)
│
├── src/
│   ├── generated/
│   │   ├── client/          # TypeScript fetch clients (gerados de .proto)
│   │   └── server/          # Handler interfaces (gerados de .proto)
│   ├── api/                 # Handlers das Edge Functions Vercel
│   │   └── [domain]/v1/     # Ex: aviation/v1/list-airport-delays.ts
│   └── ...                  # Lógica de frontend
│
├── proto/                   # Definições Protocol Buffer (.proto)
├── docs/
│   └── api/                 # OpenAPI 3.1.0 specs (geradas)
├── tests/
│   └── map-harness.html     # Harness Playwright para testes de mapa
└── relay/                   # Código do Railway WebSocket relay
    └── ...                  # Node.js: AIS, Telegram MTProto, OREF polling
```

### 3.2 CI/CD no GitHub

- **GitHub Actions**: TypeCheck + Lint em cada Pull Request
- **Releases automáticos**: Via `github-actions` bot (GPG signed, key B5690EEEBB952194)
- **Frequência de releases**: Múltiplos releases por dia em período de alta atividade
- **Pull Requests**: 648+ PRs ao total (contagem de março 2026)
- **Contribuidores externos**: Comunidade ativa (Yigtwxx, fuleinist, Chinmaya-India, FayezBast, fredzannarbor, etc.)
- **LLMs usados no desenvolvimento**: Pull requests tagueados com `codex`, `claude`, `cursor`

### 3.3 Observações Técnicas do CLAUDE.md

O arquivo `CLAUDE.md` é um guia específico para desenvolvedores usando Claude AI no projeto. Isso sugere que o próprio desenvolvimento usa Assistentes de IA como ferramenta primária de codificação — modelo "vibe coding" colaborativo.

---

## 4. Funcionalidades Principais

### 4.1 Mapa Interativo Global

| Feature | Detalhe |
|---------|---------|
| **Renderização** | deck.gl + MapLibre GL JS, 60fps WebGL |
| **Modos** | 3D Globe (pitch/rotação) e Flat Map (via env var) |
| **Layers** | 40+ camadas toggleáveis |
| **Clustering** | Supercluster — agrupa em zoom baixo, expande em zoom alto |
| **Presets regionais** | 8: Global, Americas, Europe, MENA, Asia, Africa, Oceania, Latin America |
| **Time filter** | 1h, 6h, 24h, 48h, 7d |
| **URL state** | `?view=mena&zoom=4&layers=conflicts,bases` — estado shareable |
| **Country detection** | Local via GeoJSON + ray-casting (sub-milissegundo, sem rede) |
| **Progressive disclosure** | Bases/nuclear/datacenters aparecem só em zoom avançado |

**Layers disponíveis** (40+):
- Iran Attacks (dedicado)
- Conflict Zones (UCDP + ACLED)
- Intel Hotspots
- Military Bases (220+ bases de 9 países)
- Nuclear Sites + Gamma Irradiators
- Spaceports
- Undersea Cables + Cable Health
- Pipelines (oil & gas)
- AI Datacenters (111 clusters)
- Strategic Ports (83 portos, 6 tipos)
- Trade Routes (19 rotas globais)
- Protests/Unrest
- Natural Disasters
- GPS/GNSS Jamming Zones (H3 hex grid)
- Cyber Threat IOCs
- Sanctions Regimes
- Internet Outages
- Climate Anomalies
- Satellite Fire Detection (NASA FIRMS)
- Critical Mineral Deposits
- Displacement Flows
- Stock Exchanges (Finance variant)
- Financial Centers (Finance variant)
- Central Banks (Finance variant)
- Gulf FDI Investments (Finance variant)
- Tech HQs, Cloud Regions (Tech variant)
- Vessel Traffic (AIS)
- Military Aircraft (ADS-B)
- Airport Delays
- Day/Night Solar Terminator overlay

### 4.2 Live News & Video

| Feature | Detalhe |
|---------|---------|
| **RSS Feeds** | 150+ feeds em 25 categorias |
| **Streams de TV** | 8+ padrão: Bloomberg, Sky News, Al Jazeera, Euronews, DW, France24, CNBC, Al Arabiya |
| **Biblioteca expandida** | 30+ canais (Fox, BBC, CNN Turk, TRT, RT via HLS, CBS, NBC, CNN Brasil, etc.) |
| **HLS nativo** | 10 canais sem iframe YouTube (RT exclusivo via HLS — banido do YT) |
| **Webcams ao vivo** | 22 streams de hotspots geopolíticos em 5 regiões |
| **Qualidade** | Auto / 360p / 480p / 720p (global, persiste em localStorage) |
| **Idle-aware** | Pausa após 5 min de inatividade; destrói DOM quando tab é oculta |
| **Custom keywords** | Monitor de palavras-chave definidas pelo usuário com alertas em tempo real |

**Regiões de webcams**:
- Iran/Attacks: Tehran, Tel Aviv, Jerusalem (grid 2×2)
- Middle East: Jerusalem (Western Wall), Tehran, Tel Aviv, Meca
- Europe: Kyiv, Odessa, Paris, St. Petersburg, London
- Americas: Washington DC, New York, Los Angeles, Miami
- Asia-Pacific: Taipei, Shanghai, Tokyo, Seoul, Sydney

### 4.3 AI Insights

| Feature | Detalhe |
|---------|---------|
| **World Brief** | Sumário LLM dos principais eventos com fallback chain de 4 tiers |
| **Country Brief** | Dossier completo por país ao clicar no mapa |
| **Threat Classification** | Pipeline 3 estágios: keywords → browser ML → LLM |
| **CII Score** | Country Instability Index (0–100) por país |
| **Focal Point Detection** | Correlação de entidades entre múltiplos feeds |
| **Keyword Spike Detection** | Janela 2h vs. baseline 7 dias |
| **Strategic Posture** | 9 teatros militares monitorados continuamente |

### 4.4 Country Brief Pages

Ao clicar em qualquer país no mapa, abre um dossier full-page com layout de 2 colunas:

**Coluna esquerda**:
- CII ring animado (SVG) com 4 componentes (Unrest, Conflict, Security, Information)
- AI Brief com citações inline [1]–[8]
- Top 8 headlines relevantes (filtradas por alias do país)

**Coluna direita**:
- Active Signals (chips em tempo real)
- 7-Day Timeline (D3.js com 4 lanes: protest, conflict, natural, military)
- Prediction Markets (top 3 Polymarket por volume)
- Infrastructure Exposure (raio de 600km do centroide)

**Exportação**: JSON estruturado, CSV flat, PNG imagem, PDF via print dialog.

### 4.5 Módulos de Inteligência

| Módulo | Descrição |
|--------|-----------|
| **CII** | Score 0–100 por país. 23 nações tier-1 com perfis ajustados; todas as demais com baseline padrão |
| **DEFCON Score** | Baseado em PizzINT — monitoramento de foot traffic em locais militares/governamentais |
| **GDELT Tension Index** | Índice de tensão complementar |
| **Temporal Anomaly Detection** | Welford's online algorithm, janela 90 dias, z-scores 1.5/2.0/3.0 |
| **Geographic Convergence** | Grid 1°×1°, 24h window — 3+ tipos de evento = alerta |
| **Theater Posture** | 9 teatros: Iran/Persian Gulf, Taiwan Strait, Baltic, Korean Peninsula, etc. |
| **Infrastructure Cascade** | Grafo de dependências com BFS (profundidade ≤3) |
| **USNI Fleet Intel** | Relatórios semanais da US Naval Institute + AIS em tempo real |

### 4.6 Mercados Financeiros

| Módulo | Dados |
|--------|-------|
| **Crypto** | BTC, ETH, SOL, XRP via CoinGecko |
| **BTC ETF flows** | IBIT, FBTC, GBTC + 7 outros |
| **Stablecoins** | USDT, USDC, DAI, FDUSD, USDe — peg health |
| **Fear & Greed** | 30-day history |
| **BTC Technical** | SMA50, SMA200, VWAP, Mayer Multiple |
| **Macro signals** | JPY liquidity, QQQ/XLP regime, BTC hash rate |
| **7-signal radar** | Veredicto composto BUY/CASH |
| **Oil & Energy** | WTI/Brent via EIA API |

### 4.7 Outros Módulos

- **Telegram OSINT** — 27 canais (Aurora Intel, BNO News, OSINTdefender, DeepState, LiveUAMap, etc.) via MTProto
- **OREF Sirens** — Alertas de foguetes Israel em tempo real (proxy residencial israelense)
- **GPS/GNSS Jamming** — H3 hex grid de interferência, alimenta CII
- **Security Advisories** — US State Dept, Australia DFAT, UK FCDO, New Zealand MFAT
- **Airport Delays** — 128 aeroportos: FAA (14 EUA) + AviationStack (114 intern.) + ICAO NOTAM (46 MENA)
- **Prediction Markets** — Polymarket (3-tier JA3 bypass)
- **Historical Playback** — Snapshots no IndexedDB com time slider
- **Cmd+K Command Palette** — Busca fuzzy em 20+ tipos de resultado

---

## 5. Fontes de Dados e APIs

### 5.1 Geopolítica e Conflitos

| Fonte | Dados | Frequência |
|-------|-------|-----------|
| **ACLED** | Conflict events, protests, riots (30 dias) | Tokenized API, Redis 10min TTL |
| **UCDP** | Armed conflicts, GED (battle deaths 1000+/ano) | API version auto-discovery |
| **GDELT** | Geo-events, protestos (7 dias), GDELT Tension Index | Polling |
| **UN OCHA HAPI** | Humanitarian data, displacement flows | Periodic |
| **PizzINT API** | Foot traffic em locais militares/gov (DEFCON score) | Polling |

### 5.2 Militar e Estratégico

| Fonte | Dados |
|-------|-------|
| **OpenSky Network** | ADS-B flight tracking (WebSocket via Railway relay) |
| **Wingbits API** | Aircraft enrichment — registro, modelo, operador militar |
| **AIS Stream** | Vessel tracking (WebSocket via Railway relay) |
| **gpsjam.org** | GPS/GNSS jamming (H3 hex grid, de ADS-B Exchange) |
| **USNI** | US Naval Institute fleet deployment reports (semanal) |
| **Dados estáticos** | 220+ bases militares de 9 países (curated) |
| **oref.org.il** | Israel OREF sirens (via residential proxy israelense + curl) |

### 5.3 Desastres Naturais

| Fonte | Cobertura | Frequência |
|-------|-----------|-----------|
| **USGS** | Terremotos M4.5+ | 5 minutos |
| **GDACS** | UN disaster alerts (earthquakes, floods, cyclones, volcanoes) | Real-time |
| **NASA EONET** | 13 categorias de eventos naturais (30 dias open) | Real-time |
| **NASA FIRMS** | VIIRS thermal hotspots (fires) | Real-time |

### 5.4 Clima e Ambiente

| Fonte | Dados |
|-------|-------|
| **Open-Meteo ERA5** | Temperature/precipitation anomalies (30-day baseline) |
| **WorldPop** | Population density (exposure estimation por evento) |

### 5.5 Infraestrutura e Marítimo

| Fonte | Dados |
|-------|-------|
| **NGA Navigational Warnings** | Cable repair advisories, maritime safety |
| **Cloudflare Radar** | Internet outages globais |
| **FAA ASWS** | Ground delays/stops para 14 aeroportos EUA |
| **AviationStack API** | Delays para 114 aeroportos internacionais |
| **ICAO NOTAM API** | 46 aeroportos MENA — fechamentos por atividade militar |
| **EIA API** | WTI/Brent crude, US production, inventory levels |
| **Dados estáticos** | 83 portos estratégicos, 111 datacenters AI, undersea cables |

### 5.6 Cyber Security

| Fonte | IOC Type |
|-------|---------|
| **Feodo Tracker** (abuse.ch) | C2 servers (botnet C&C) |
| **URLhaus** (abuse.ch) | Malware distribution URLs |
| **C2IntelFeeds** | Community-sourced C2 indicators |
| **AlienVault OTX** | Mixed threat exchange pulse IOCs |
| **AbuseIPDB** | Crowd-sourced malicious IPs |
| **Ransomware.live** | Active ransomware group feeds |
| **ipinfo.io / freeipapi.com** | Geo-enriquecimento de IPs (cached 24h Redis) |

### 5.7 Notícias e Inteligência

| Fonte | Dados |
|-------|-------|
| **150+ RSS feeds** | Geopolitics, defense, energy, tech, finance |
| **Telegram (27 canais)** | OSINT, breaking news via GramJS MTProto |
| **US State Dept / DFAT AU / FCDO UK / MFAT NZ** | Travel advisories |
| **CDC / ECDC / WHO** | Health/travel notices |
| **Polymarket** | Prediction markets (3-tier JA3 bypass) |

### 5.8 Mercados Financeiros

| Fonte | Dados |
|-------|-------|
| **CoinGecko** | Crypto prices (BTC, ETH, SOL, XRP, etc.) |
| **Finnhub** | Stock indices por país |
| **FRED (St. Louis Fed)** | Economic series |
| **BIS** | Policy rates, REER, credit-to-GDP |
| **WTO** | Trade restrictions, tariff trends, bilateral flows |
| **EIA** | Oil & gas data |

### 5.9 Feeds LLM / IA

| Fonte | Uso |
|-------|-----|
| **Ollama** (local) | Summarization, classification — nenhum dado sai da máquina |
| **LM Studio** | Qualquer endpoint OpenAI-compatible local |
| **Groq** (cloud) | Llama 3.1 8B, temp 0.3 — fallback rápido na nuvem |
| **OpenRouter** (cloud) | Multi-model fallback |
| **Transformers.js** (browser) | T5-small ONNX — último recurso, offline |

---

## 6. Design e UX

### 6.1 Filosofia Visual

O design é claramente inspirado em **centros de comando militares e terminais OSINT** — fundo escuro (dark mode por padrão), verde-terminal para elementos ativos, badges de severidade com código de cores (vermelho = crítico, laranja = elevado, amarelo = monitorando, azul = base, roxo = nuclear, verde = datacenter).

### 6.2 Layout do Dashboard

**Topo (header)**:
- Versão atual (v2.5.21)
- Link para @eliehabib (Twitter)
- Link para GitHub
- Status LIVE
- Seletor de região (Global, Americas, Europe, MENA, etc.)
- DEFCON Score (badge numérico com cor)
- Contador de Intelligence Findings
- Botão Search (Cmd+K)
- Copy Link
- Controles de tema/refresh/configurações

**Corpo principal** (3 colunas no desktop):
1. **Left panel** (abaixo do mapa): Live News (Bloomberg, SkyNews, Euronews, DW, CNBC, France24, Al Arabiya, Al Jazeera)
2. **Center**: Mapa interativo (dominante, ~50% da viewport)
3. **Right panel**: Live Webcams (grid 2×2 por região) + AI Insights / AI Strategic Posture

**Layers panel** (canto superior esquerdo do mapa):
- Checkboxes para cada layer com ícone e nome
- Iran Attacks, Intel Hotspots, Conflict Zones, Military Bases, Nuclear Sites, Gamma Irradiators, Spaceports, Undersea Cables, Pipelines, AI Data Centers...

**Legend** (canto inferior do mapa):
- High Alert (vermelho) · Elevated (laranja) · Monitoring (amarelo) · Base (azul) · Nuclear (roxo) · Datacenter (verde)

### 6.3 Sistema de Layout Responsivo

| Largura | Layout |
|---------|--------|
| < 768px | Warning modal — recomenda desktop; mapa touch-otimizado |
| 768px–2000px | Grid padrão vertical: mapa no topo, panels em `auto-fill` (minmax 280px, 1fr) |
| 2000px+ | L-shape ultra-wide: mapa flutua à esquerda (60% width), panels à direita e abaixo |

A implementação ultra-wide usa `display: contents` + `float: left` — sem JavaScript de layout.

### 6.4 Personalização

- **Dark/Light theme** — toggle no header, sem flash de tema errado (inline script antes do mount)
- **Panel drag-and-drop** — reordenamento de painels persistido em localStorage
- **Panel resize** — drag handles (span-1 a span-4 grid rows)
- **Map pin mode** — fixa o mapa durante scroll (📌 botão)
- **Feature toggles** — 15 toggles de runtime para ativar/desativar fontes
- **Cmd+K** — command palette com busca fuzzy em 20+ tipos

### 6.5 Tipografia e Temas

- **Font mono**: SF Mono → Monaco → Cascadia Code → Fira Code → DejaVu Sans Mono → Liberation Mono
- Suporte **RTL** nativo (árabe, hebraico) com stacks de fonte específicas (Geeza Pro para árabe, PingFang SC para chinês)
- 20+ CSS custom properties overrideadas no light mode

---

## 7. Variantes da Plataforma

O sistema roda em **4 variantes** a partir de um único codebase:

| Variante | URL | Foco |
|---------|-----|------|
| **World Monitor** | worldmonitor.app | Geopolítica, militar, conflitos, infraestrutura |
| **Tech Monitor** | tech.worldmonitor.app | Startups, AI/ML, cloud, cybersecurity |
| **Finance Monitor** | finance.worldmonitor.app | Mercados, bancos centrais, Gulf FDI |
| **Happy Monitor** | happy.worldmonitor.app | Notícias positivas, tendências boas |

A mudança entre variantes é feita com um clique no header bar. Cada variante tem:
- Feed set próprio de RSS (~25 categorias para geopolítico, ~20 para tech, ~18 para finance)
- Layers do mapa específicas (ex: Finance tem 92 bolsas + 13 bancos centrais + 64 Gulf FDI investments)
- Prompts de LLM diferentes (geopolítico foca em escaladas; finance em movimentos de mercado)
- Categorias de notícias com 5 requisições concorrentes em Finance (vs. 3 padrão) para cold starts mais rápidos

---

## 8. Deployment e Infraestrutura

### 8.1 Infraestrutura em Produção

```
worldmonitor.app  ────────────────────→  Vercel (SPA + Edge Functions)
                                              │
                                              ├──→ Upstash Redis (cache)
                                              └──→ Railway relay (WS + proxy)

api.worldmonitor.app  ────────────────→  Vercel Edge Cache (Cloudflare)

proxy.worldmonitor.app  ──────────────→  Cloudflare edge caching
                                              │
                                              └──→ Railway relay (persistent Node.js)
```

**Vercel** serve:
- SPA (single-page app) compilada com Vite
- 60+ Edge Functions (um único gateway em `api/[domain]/v1/[rpc].ts`)
- Assets estáticos com cache agressivo

**Railway** serve:
- Container Node.js persistente (sem cold start)
- WebSocket relay para ADS-B (OpenSky Network), AIS (Aistream)
- Telegram MTProto client (GramJS)
- OREF polling (via curl + residential proxy israelense)
- Polymarket proxy com circuit breaker

**Upstash Redis** serve:
- Cache para todas as respostas de API
- Temporal baselines (Welford's algorithm, 90 dias)
- Rate limiting

### 8.2 Self-Hosting

O projeto suporta self-hosting via Docker (PR em andamento: `Chinmaya-India:feat/docker-self-hosting`). O desktop app já serve como solução self-hosted completa com sidecar local.

### 8.3 Variáveis de Ambiente

O projeto exige 12+ API keys configuráveis:
- `GROQ_API_KEY` — LLM fallback cloud
- `OPENROUTER_API_KEY` — LLM fallback alternativo
- `ACLED_API_TOKEN` — conflict data
- `AVIATIONSTACK_API` — airport delays internacionais
- `FINNHUB_API_KEY` — stock indices
- `FRED_API_KEY` — economic series
- `EIA_API_KEY` — oil/energy
- `VITE_WS_RELAY_URL` — Railway relay URL (client)
- `WS_RELAY_URL` — Railway relay URL (server-side)
- `UPSTASH_REDIS_REST_URL` / `UPSTASH_REDIS_REST_TOKEN` — Redis
- `CONVEX_URL` — Convex (social features)

O desktop app armazena todas essas keys em **OS keychain** (macOS Keychain / Windows Credential Manager) como um único blob JSON — reduzindo prompts de autorização de 20+ para apenas 1.

### 8.4 GitHub Actions CI

- **Typecheck**: Roda em cada PR (TypeScript strict)
- **Lint**: Roda em cada PR (ESLint)
- **Desktop Build**: Builds automáticos para macOS-arm64, macOS-x64, Windows-exe, Windows-msi, Linux-appimage
- **Smoke test Linux**: AppImage via weston+XWayland
- **Releases**: github-actions bot cria release automaticamente com GPG signature

---

## 9. Inteligência Artificial

### 9.1 Pipeline de Sumarização (4 Tiers)

```
Requisição de sumário
(dedup Jaccard > 0.6)
        │
        ▼
Tier 1: Ollama / LM Studio (local)
        │ timeout/error
        ▼
Tier 2: Groq (cloud) — Llama 3.1 8B, temp 0.3
        │ timeout/error
        ▼
Tier 3: OpenRouter (cloud) — multi-model
        │ timeout/error
        ▼
Tier 4: Transformers.js T5-small (browser ONNX) — offline
```

- Timeout de 5s por tier antes de fazer fallback
- Redis dedup: mesmas headlines para 1.000 usuários = 1 chamada LLM
- Cache key: `summary:v3:{mode}:{variant}:{lang}:{hash}`

### 9.2 Pipeline de Classificação de Ameaças (3 Estágios)

| Estágio | Método | Latência |
|---------|--------|---------|
| **1. Keyword classifier** | ~120 keywords por 4 tiers de severidade, 14 categorias | Instantâneo |
| **2. Browser ML** | Transformers.js NER + sentiment (ONNX) | Assíncrono |
| **3. LLM classifier** | Groq/Ollama batch RPC, cached 24h | Batch async |

O resultado LLM sobrescreve keyword apenas se confidence for maior. Classificações carregam tag `source: 'keyword'|'ml'|'llm'`.

### 9.3 Country Instability Index (CII)

Formula ponderada 0–100:

| Componente | Peso | Cálculo |
|-----------|------|---------|
| Baseline risk | 40% | Pré-configurado por país (estrutura de fragilidade) |
| Unrest events | 20% | Log para democracias, linear para autoritarismos |
| Security activity | 20% | Voos militares (3pts) + navios (5pts), presença estrangeira dobrada |
| Information velocity | 20% | Frequência de notícias × multiplicador de severidade (log-scaled) |

**Boosts adicionais**:
- GPS jamming: até +35 no componente Security
- OREF alerts: até +50 no componente Conflict (Israel)
- Travel advisories "Do Not Travel": força mínimo CII ≥ 60
- Conflict floors: Ukraine ≥55, Syria ≥50

**23 países tier-1** com perfis ajustados: US, Russia, China, Ukraine, Iran, Israel, Taiwan, North Korea, Saudi Arabia, Turkey, Poland, Germany, France, UK, India, Pakistan, Syria, Yemen, Myanmar, Venezuela, Brazil, UAE, Japan.

### 9.4 Browser-Side ML Pipeline

| Capacidade | Modelo |
|-----------|--------|
| Embeddings de texto | sentence-similarity |
| Classificação de sequência | threat-classifier |
| Sumarização | T5-small |
| Named Entity Recognition | NER pipeline |

O clustering híbrido combina Jaccard (threshold 0.4, instantâneo) com similaridade semântica ML (cosine 0.78, async). Desabilitado automaticamente em mobile.

---

## 10. Aplicativo Desktop (Tauri)

O projeto oferece um app nativo construído com **Tauri** (Rust + WebView) para macOS, Windows e Linux.

### Diferenciais do Desktop vs. Web

| Feature | Web | Desktop |
|---------|-----|---------|
| API keys | Env vars no Vercel | OS Keychain (nunca em plaintext) |
| AI processing | Groq/OpenRouter cloud | Ollama local (zero cloud dependency) |
| Data privacy | Sai para o servidor | Fica na máquina (modo air-gapped) |
| YouTube playback | Direto | Via cloud embed proxy (WKWebView restriction) |
| Sidecar API | Cloud Vercel | Node.js sidecar local (60+ handlers) |
| Auto-update | N/A | Polling /api/version a cada 6h |

### Configurações (Cmd+,)

- **LLMs tab**: Ollama endpoint, seleção de modelo (auto-discovery), Groq, OpenRouter
- **API Keys tab**: 12+ credenciais com validação por chave
- **Debug & Logs tab**: Traffic log, modo verbose, últimos 200 requests

### Assets de Release (10 assets por versão)

- `WorldMonitor-{version}-macos-arm64.dmg`
- `WorldMonitor-{version}-macos-x64.dmg`
- `WorldMonitor-{version}-windows.exe`
- `WorldMonitor-{version}-windows.msi`
- `WorldMonitor-{version}-linux.AppImage`
- Variantes: full, tech, finance

---

## 11. Considerações de Segurança e Privacidade

### 11.1 Modelo de Privacidade por Nível

| Nível | Setup | Dados saem da máquina? |
|-------|-------|----------------------|
| **Web App** | worldmonitor.app | Sim — tudo no Vercel |
| **Desktop + Cloud Keys** | Tauri + APIs externas | Parcialmente |
| **Air-Gapped Local** | Tauri + Ollama | Não |

### 11.2 Medidas de Segurança Técnica

- **Token-authenticated sidecar**: Token único por sessão no sidecar local
- **OS Keychain vault**: Secrets consolidados em um único entry JSON
- **CORS enforcement**: Domain-allowlist no RSS proxy
- **Rate limiting**: Sliding window 300 req/min, retryAfter em 429
- **Circuit breakers**: Per-feed com cooldown de 5 minutos
- **Sentry error tracking**: Com noise filters para evitar spam de erros conhecidos
- **Security headers**: Adicionados ao deployment Vercel (v2.5.16)

### 11.3 Limitações de Qualidade de Dados

- Sem verificação pesada das fontes RSS além de heurísticas de IA
- Fontes de propaganda estatal (RT/Russia Today) incluídas com contexto
- AI classifiers podem ser enganados por desinformação em escala
- Dados de mercado sem garantias de precisão para trading

---

## 12. Estado Atual e Comunidade

### 12.1 Tração

- **10.000+ GitHub stars** em semanas
- **648+ Pull Requests** processados
- **395+ GitHub Actions runs** 
- **Viralizou no Reddit, LinkedIn, Twitter/X** em fevereiro 2026
- Citado no /r/lebanon como projeto Open Source libanês de referência

### 12.2 Desenvolvimento Ativo

- Releases múltiplos por dia (v2.5.14 até v2.5.21 em apenas 4 dias, 26-01/03/2026)
- PRs de contribuidores externos em múltiplos países
- Uso explícito de LLMs (Claude, Codex, Cursor) no desenvolvimento
- Features recentes (v2.5.21): mobile map nativo, OREF history waves, GPS jamming Redis caching, RT HLS, Korea localization, server-side RSS aggregation (reduz custos Vercel ~70-95%)

### 12.3 Roadmap (inferido dos PRs)

- Docker self-hosting completo (`Chinmaya-India:feat/docker-self-hosting`)
- RAG-powered analysis com vector store local (`Yigtwxx:feat/rag-powered-analysis`)
- "Happy World Monitor" em desenvolvimento
- Notificações push em mobile
- Performance improvements (CPU/RAM são críticas na versão atual)
- Variant "Codexes" para avaliação literária (`fredzannarbor`)

### 12.4 Pontos de Atenção

1. **Alto consumo de recursos**: Usuários reportam RAM e CPU elevados (muitos WebGL + streams de vídeo simultâneos)
2. **Voltado para desktop**: Tela < 768px mostra aviso de incompatibilidade
3. **Custo de API**: PRs recentes focam em reduzir custos Vercel (server-side RSS aggregation, cache TTL bumps)
4. **Dependência do Railway**: WebSocket relay é ponto único de falha para AIS/ADS-B/Telegram
5. **OREF via residential proxy**: Requer proxy residencial israelense (Akamai WAF bloqueia datacenter IPs)

---

## Resumo Executivo

| Atributo | Valor |
|----------|-------|
| **Tipo** | Dashboard OSINT/inteligência global open source |
| **Licença** | MIT |
| **Frontend** | TypeScript + Vite (SPA), deck.gl, MapLibre, D3.js |
| **Backend** | Vercel Edge Functions + Railway WebSocket relay |
| **Cache** | Upstash Redis |
| **CDN** | Cloudflare |
| **Desktop** | Tauri (macOS, Windows, Linux) |
| **AI** | Ollama → Groq → OpenRouter → Transformers.js (fallback chain) |
| **Fontes de dados** | 150+ RSS, ACLED, GDELT, UCDP, OpenSky, AIS, NASA, USGS, Cloudflare Radar, Polymarket, 6 cyber feeds, 4 gov advisories, 27 Telegram channels |
| **Custo para usuário** | 100% gratuito |
| **Auto-hospedagem** | Possível (Docker em desenvolvimento) |
| **GitHub** | https://github.com/koala73/worldmonitor |
| **Versão atual** | v2.5.21 (01/03/2026) |
| **Stars** | 10.000+ |

---

*Análise baseada em dados públicos: código-fonte GitHub, README, releases, actions, screenshots diretos do site em 01/03/2026 e publicações no Reddit/LinkedIn/Twitter.*
