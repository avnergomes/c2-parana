# Fontes Abertas de Dados — Estado do Paraná
### Mapeamento para Dashboard Command & Control (SaaS)

> **Objetivo:** Catalogar todas as fontes de dados abertos disponíveis sobre o Paraná para alimentar um painel C&C estilo WorldMonitor, comercializado como SaaS.
>
> **Atualizado em:** 01/03/2026
>
> **Legenda de dificuldade:** 🟢 Fácil · 🟡 Médio · 🔴 Difícil

---

## Sumário de Categorias

| # | Categoria | Fontes mapeadas | Fontes com API REST |
|---|-----------|-----------------|---------------------|
| 1 | [Clima / Meteorologia](#1-clima--meteorologia) | 6 | 3 |
| 2 | [Saúde](#2-saúde) | 7 | 4 |
| 3 | [Segurança Pública](#3-segurança-pública) | 5 | 2 |
| 4 | [Economia / Agronegócio](#4-economia--agronegócio) | 8 | 3 |
| 5 | [Trânsito / Transporte](#5-trânsito--transporte) | 6 | 2 |
| 6 | [Meio Ambiente](#6-meio-ambiente) | 9 | 4 |
| 7 | [Notícias / Mídia](#7-notícias--mídia) | 5 | 5 (RSS) |
| 8 | [Energia](#8-energia) | 4 | 2 |
| 9 | [Educação](#9-educação) | 5 | 2 |
| 10 | [Câmeras ao Vivo](#10-câmeras-ao-vivo) | 5 | 1 |
| 11 | [Dados Geoespaciais](#11-dados-geoespaciais) | 7 | 5 |
| 12 | [Defesa Civil](#12-defesa-civil) | 5 | 1 |
| 13 | [Qualidade da Água](#13-qualidade-da-água) | 5 | 3 |
| 14 | [Dados Legislativos](#14-dados-legislativos) | 5 | 2 |
| | **TOTAL** | **82** | **39** |

---

## 1. Clima / Meteorologia

> Cobertura: rede INMET (~20 estações automáticas no PR), SIMEPAR (100+ estações próprias), alertas em tempo real.

| Fonte | URL | Tipo de Acesso | Atualização | Formato | Dificuldade | Custo |
|-------|-----|---------------|-------------|---------|-------------|-------|
| INMET Estações (mapa + leituras) | https://mapas.inmet.gov.br/ | REST API JSON | Tempo real (10 min) | JSON | 🟢 Fácil | Gratuito |
| INMET Alertas Meteorológicos | https://alertas2.inmet.gov.br/ | Web / download JSON | Diário | JSON/HTML | 🟡 Médio | Gratuito |
| INMET BDMEP (histórico) | https://bdmep.inmet.gov.br | Download via formulário | Diário (histórico) | CSV | 🟡 Médio | Gratuito |
| INMET Portal | https://portal.inmet.gov.br | Download CSV + boletins | Diário | CSV | 🟡 Médio | Gratuito |
| SIMEPAR (rede PR) | https://www.simepar.br / https://operacaosimepar.zendesk.com | Solicitação formal (ofício); dados comerciais pagos | 15 min | CSV / planilha | 🔴 Difícil | Pago (comercial) / Gratuito (pesquisa com ofício) |
| Simeagro (SIMEPAR + OCEPAR) | https://simeagro.pr.gov.br | Portal web (API não documentada publicamente) | Horário | JSON | 🔴 Difícil | Não determinado |

**Notas técnicas:**
- **INMET API de estações:** `GET https://apitempo.inmet.gov.br/estacao/dados/{cod_estacao}/{data_inicial}/{data_final}` — retorna temperatura, umidade, pressão, vento e precipitação.
- **SIMEPAR** possui a rede mais densa do PR (100+ estações + radares + previsão numérica). Acesso acadêmico requer ofício de instituição de ensino. Para uso comercial/SaaS, contato direto é necessário para licenciamento.
- Para alertas em tempo real sem bloqueio, a combinação **INMET Alertas + NASA FIRMS** (ver seção Meio Ambiente) cobre ~90% dos casos de uso.

---

## 2. Saúde

> Cobertura: vigilância epidemiológica, doenças de notificação compulsória (arboviroses, COVID), vacinação, leitos SUS.

| Fonte | URL | Tipo de Acesso | Atualização | Formato | Dificuldade | Custo |
|-------|-----|---------------|-------------|---------|-------------|-------|
| InfoDengue API | https://info.dengue.mat.br/api/ | REST API (sem autenticação) | Semanal | JSON | 🟢 Fácil | Gratuito |
| OpenDataSUS | https://opendatasus.saude.gov.br | API REST (Elasticsearch) | Variável (dias) | JSON | 🟡 Médio | Gratuito |
| DATASUS TabNet (SIH, SIM, SINAN) | https://datasus.saude.gov.br | Web (TabNet) + CSV download | Mensal | CSV | 🟡 Médio | Gratuito |
| e-SUS Notifica API (COVID/Gripe) | https://elasticsearch-public.saude.gov.br | REST/Elasticsearch (IP cadastrado) | Diário | JSON | 🔴 Difícil | Gratuito |
| SESA-PR (Secretaria Saúde PR) | https://www.saude.pr.gov.br | Boletins PDF + portal epidemiológico | Semanal | PDF/HTML | 🔴 Difícil (scraping) | Gratuito |
| Portal Dengue PR | https://www.dengue.pr.gov.br | Portal informativo | Semanal | HTML | 🔴 Difícil (scraping) | Gratuito |
| RNDS / Vacinação (FHIR) | https://rnds.saude.gov.br | API FHIR R4 (autenticação Gov.br) | Diário | JSON (FHIR) | 🔴 Difícil | Gratuito |

**Notas técnicas:**
- **InfoDengue:** endpoint principal `GET https://info.dengue.mat.br/api/alertcity?geocode={ibge_code}&disease=dengue&format=json&ew_start=1&ew_end=52&ey_start=2024&ey_end=2024`. Retorna alertas semanas epidemiológicas. Suporta dengue, chikungunya e zika. Geocódigos dos municípios PR estão na faixa 410XXX.
- **OpenDataSUS:** base sobre leitos, CNES (estabelecimentos de saúde), procedimentos ambulatoriais. Filtrar por UF=41.
- **e-SUS Notifica:** requer cadastro de IP fixo no portal gov.br; alternativa é usar o download semanal disponível no OpenDataSUS.

---

## 3. Segurança Pública

> Cobertura: acidentes e multas de trânsito (PRF), criminalidade (SINESP), boletins SESP-PR.

| Fonte | URL | Tipo de Acesso | Atualização | Formato | Dificuldade | Custo |
|-------|-----|---------------|-------------|---------|-------------|-------|
| PRF Dados Abertos (acidentes + multas) | https://www.gov.br/prf/pt-br/acesso-a-informacao/dados-abertos/dados-abertos-da-prf | Download CSV | Mensal | CSV | 🟢 Fácil | Gratuito |
| SINESP — Estatísticas Criminalidade | https://dados.gov.br/dados/conjuntos-dados/sistema-nacional-de-estatisticas-de-seguranca-publica | Download CSV | Mensal | CSV | 🟢 Fácil | Gratuito |
| SESP-PR / CAPE (boletins anuais) | https://www.seguranca.pr.gov.br | Boletins PDF | Semestral | PDF/HTML | 🔴 Difícil | Gratuito |
| Antecedentes Criminais PF (API) | https://www.gov.br/conecta/catalogo/apis/antecedentes-criminais | REST API (autenticação Gov.br) | Tempo real | JSON | 🟡 Médio | Gratuito |
| Portal Transparência Polícia Civil PR | https://www.delegacias.pr.gov.br | Web portal | Variável | HTML | 🔴 Difícil (scraping) | Gratuito |

**Notas técnicas:**
- **PRF** publica arquivos CSV anuais com geolocalização de cada acidente. Filtrar por coluna `uf = PR`. Inclui tipo de acidente, causa, condições da via, vítimas.
- **SINESP:** dados por UF, tipo de crime (homicídio, furto, roubo, etc.), desagregados mensalmente. Não há API REST; apenas downloads periódicos.
- Para dados em **tempo real** de ocorrências, não há fonte pública disponível no PR — o COPOM/SESP é sistema interno.

---

## 4. Economia / Agronegócio

> Cobertura: cotações agrícolas diárias (PR é maior produtor de soja e frango do Brasil), emprego formal (CAGED), indicadores socioeconômicos IPARDES.

| Fonte | URL | Tipo de Acesso | Atualização | Formato | Dificuldade | Custo |
|-------|-----|---------------|-------------|---------|-------------|-------|
| DERAL/SEAB — Cotações Agropecuárias | https://celepar7.pr.gov.br/sima/cotdiap.asp | Web scraping (tabela HTML) | Diário | HTML → CSV | 🟡 Médio | Gratuito |
| SEAB — Previsão Safra | https://www.agricultura.pr.gov.br | Portal / PDF / Excel | Semanal | PDF/Excel | 🟡 Médio | Gratuito |
| CAGED (novo — emprego formal) | https://www.gov.br/trabalho-e-emprego/pt-br/assuntos/estatisticas-trabalho/o-pdet/o-que-e-caged | Download CSV | Mensal | CSV | 🟢 Fácil | Gratuito |
| IBGE API Cidades e Agregados | https://servicodados.ibge.gov.br/api/v1/ | REST API | Variável | JSON | 🟢 Fácil | Gratuito |
| RAIS (vínculos empregatícios) | https://www.gov.br/trabalho-e-emprego/pt-br | Download CSV | Anual | CSV | 🟡 Médio | Gratuito |
| MDIC — Exportações/Importações PR | https://www.gov.br/mdic/pt-br/assuntos/comercio-exterior/estatisticas | Download CSV (COMEX STAT) | Mensal | CSV | 🟢 Fácil | Gratuito |
| IPARDES BDEweb | https://www.dados.pr.gov.br | Download CSV/Excel | Anual | CSV/Excel | 🟡 Médio | Gratuito |
| Base dos Dados (dados tratados) | https://basedosdados.org | BigQuery SQL API | Variável | JSON/CSV | 🟡 Médio | Gratuito (limitado) |

**Notas técnicas:**
- **DERAL cotações:** URL de scraping: `https://celepar7.pr.gov.br/sima/cotdiap.asp`. Tabela HTML com preços de soja, milho, trigo, frango, bovinos, suínos, leite e outros por praça paranaense. Atualizado diariamente em dias úteis.
- **IBGE Agregados API (PIB municipal PR):** `GET https://servicodados.ibge.gov.br/api/v1/pesquisas/38/indicadores/47001/resultados/41` — retorna PIB per capita por município do PR.
- **COMEX STAT:** dados desagregados por NCM, país destino/origem, UF exportadora. Filtrar `SG_UF_NCM = PR`.

---

## 5. Trânsito / Transporte

> Cobertura: rodovias federais e estaduais, fluxo de pedágios, acidentes, câmeras de tráfego.

| Fonte | URL | Tipo de Acesso | Atualização | Formato | Dificuldade | Custo |
|-------|-----|---------------|-------------|---------|-------------|-------|
| PRF Dados Abertos (acidentes rodovias federais) | https://www.gov.br/prf/pt-br/acesso-a-informacao/dados-abertos/dados-abertos-da-prf | Download CSV | Mensal | CSV | 🟢 Fácil | Gratuito |
| ANTT Dados Abertos — Rodovias | https://dados.antt.gov.br/group/rodovias | REST API + CSV (CKAN) | Variável | CSV/JSON | 🟡 Médio | Gratuito |
| ANTT — Volume Tráfego / Pedágios | https://dados.antt.gov.br | CSV/JSON download | Mensal | CSV | 🟢 Fácil | Gratuito |
| DER-PR (rodovias estaduais) | https://www.der.pr.gov.br | Portal web (sem API pública) | Variável | HTML | 🔴 Difícil (scraping) | Gratuito |
| Waze for Cities (CCP) | https://www.waze.com/ccp | REST API (parceria prefeitura/estado) | Tempo real | JSON | 🟡 Médio | Gratuito (convênio) |
| Câmeras Você na RPC | App RPC / portal (sem API pública oficial) | App móvel / stream MJPEG | Tempo real | HLS/MJPEG | 🔴 Difícil | Gratuito (app) |

**Notas técnicas:**
- **ANTT CKAN API:** `GET https://dados.antt.gov.br/api/3/action/datastore_search?resource_id={id}` — padrão CKAN; suporta filtros SQL.
- **Waze for Cities (CCP):** disponível apenas para governos e prefeituras cadastradas. Curitiba e municípios da RMC podem ter acesso. Fornece dados de incidentes, fluxo, alertas em tempo real via API.
- **DER-PR** não possui API; dados de condições de rodovias estão em PDFs de boletins e no app. Alternativa: usar HERE Traffic API ou TomTom Traffic Flow (pagos) para rodovias estaduais.

---

## 6. Meio Ambiente

> Cobertura: queimadas, desmatamento, qualidade do ar (PM2.5, CO, ozônio), cobertura vegetal, hidrologia.

| Fonte | URL | Tipo de Acesso | Atualização | Formato | Dificuldade | Custo |
|-------|-----|---------------|-------------|---------|-------------|-------|
| INPE BDQueimadas (focos de calor) | https://terrabrasilis.dpi.inpe.br/queimadas/bdqueimadas/ | REST API + download CSV | Diário (MODIS/VIIRS) | JSON/CSV/KML | 🟢 Fácil | Gratuito |
| NASA FIRMS API (focos tempo real) | https://firms.modaps.eosdis.nasa.gov/api/ | REST API (API key gratuita) | 3h (NRT) | CSV/GeoJSON | 🟢 Fácil | Gratuito |
| MapBiomas Alerta (desmatamento) | https://plataforma.alerta.mapbiomas.org | API Google Earth Engine + download | Semanal | GeoJSON | 🟡 Médio | Gratuito |
| MapBiomas (uso e cobertura solo) | https://plataforma.brasil.mapbiomas.org | GEE API + GCS download | Anual | GeoTIFF/GeoJSON | 🟡 Médio | Gratuito |
| TerraBrasilis INPE (PRODES/DETER) | https://terrabrasilis.dpi.inpe.br | WMS / WFS / REST | Mensal | GeoJSON/WFS | 🟡 Médio | Gratuito |
| MonitorAr MMA (qualidade do ar) | https://monitorar.mma.gov.br | Portal/App (sem API pública documentada) | Tempo real | HTML/App | 🔴 Difícil | Gratuito |
| AQICN / WAQI API (qualidade do ar) | https://aqicn.org/api/ | REST API (token gratuito) | Tempo real (1h) | JSON | 🟢 Fácil | Gratuito |
| IAT-PR — Qualidade do Ar (27 est.) | https://www.iat.pr.gov.br | Portal web + download | Anual | PDF/Excel | 🔴 Difícil | Gratuito |
| IAT-PR — Dados Hidrológicos/GIS | ftp://geo_iat:geo_iat@200.189.114.112 | FTP público anonimizado | Variável | SHP/DXF | 🟡 Médio | Gratuito |

**Notas técnicas:**
- **NASA FIRMS:** `GET https://firms.modaps.eosdis.nasa.gov/api/area/csv/{MAP_KEY}/VIIRS_SNPP_NRT/-54,-26.7,-48.0,-22.5/1` — retorna focos de calor das últimas 24h no bounding box do PR. API key gratuita com limite de 500 req/10min.
- **INPE BDQueimadas endpoint:** `GET https://queimadas.dgi.inpe.br/api/focos/?pais_id=33&estado_id=41&data_inicio=2024-01-01&data_fim=2024-12-31` — retorna todos os focos para o Paraná (estado_id=41).
- **AQICN:** estações em Curitiba, Londrina, Maringá, Foz do Iguaçu. `GET https://api.waqi.info/feed/{city}/?token={token}`. Dados incluem PM2.5, PM10, CO, NO2, SO2.
- **IAT FTP:** acesso com credenciais públicas `geo_iat / geo_iat` no IP `200.189.114.112`. Contém shapefiles de áreas protegidas, unidades de conservação, hidrografia.

---

## 7. Notícias / Mídia

> Cobertura: principais veículos do PR com feeds RSS para ingestão automatizada.

| Fonte | URL do Feed | Tipo de Acesso | Atualização | Formato | Dificuldade | Custo |
|-------|-------------|---------------|-------------|---------|-------------|-------|
| Gazeta do Povo | https://www.gazetadopovo.com.br/rss | RSS Feed (múltiplas editorias) | Tempo real | XML/RSS | 🟢 Fácil | Gratuito |
| G1 Paraná (Globo) | https://g1.globo.com/rss/g1/parana/ | RSS Feed | Tempo real | XML/RSS | 🟢 Fácil | Gratuito |
| Agência Estadual de Notícias PR (AEN) | https://www.parana.pr.gov.br/noticias | RSS + portal | Tempo real | HTML/RSS | 🟢 Fácil | Gratuito |
| Banda B | https://www.bandab.com.br/feed/ | RSS Feed (inferido — padrão WordPress) | Tempo real | XML/RSS | 🟢 Fácil | Gratuito |
| Tribuna do Paraná | https://tribunapr.uol.com.br | Portal web (RSS possível) | Tempo real | HTML | 🟡 Médio | Gratuito |

**Notas técnicas:**
- Para monitoramento de notícias em escala, recomendar uso do **Google News RSS** com query geolocalizada: `https://news.google.com/rss/search?q=Paran%C3%A1&hl=pt-BR&gl=BR&ceid=BR:pt-419` — agrega múltiplas fontes automaticamente.
- **AEN Paraná:** fonte oficial do governo estadual; ideal para monitorar comunicados e decretos antes de saírem no Diário Oficial.
- Considerar também **NewsAPI.org** (pago, plano básico ~$449/mês) para cobertura ampliada e filtros por localização.

---

## 8. Energia

> Cobertura: geração elétrica (Itaipu, Foz do Areia, Segredo, usinas eólicas/solares PR), carga do sistema, distribuidora COPEL.

| Fonte | URL | Tipo de Acesso | Atualização | Formato | Dificuldade | Custo |
|-------|-----|---------------|-------------|---------|-------------|-------|
| ONS Dados Abertos (geração + carga) | https://dados.ons.org.br | REST API + S3 AWS | Semi-horário / Diário | JSON/CSV/Parquet | 🟢 Fácil | Gratuito |
| ANEEL Dados Abertos | https://dadosabertos.aneel.gov.br | REST API (CKAN) | Variável | CSV/JSON | 🟢 Fácil | Gratuito |
| ANEEL Micro/Minigeração (solar DG) | https://dadosabertos.aneel.gov.br/dataset/relacao-de-empreendimentos-de-geracao-distribuida | Download CSV | Mensal | CSV | 🟢 Fácil | Gratuito |
| COPEL (distribuidora PR) | https://www.copel.com | Sem API pública disponível | — | — | N/A | — |

**Notas técnicas:**
- **ONS S3:** bucket público `s3://ons-aws-prod-opendata`. Inclui:
  - Geração por usina (inclui Itaipu, Foz do Areia, Segredo, Salto Osório, Salto Santiago — todas no PR)
  - Carga verificada semi-horária por subsistema (Sul — cobre PR/SC/RS)
  - Nível de reservatórios (Itaipu, Foz do Areia, Segredo em tempo real)
- **ONS REST API endpoint:** `GET https://dados.ons.org.br/api/3/action/datastore_search?resource_id={id}` — padrão CKAN.
- **ANEEL SIGA:** `GET https://dadosabertos.aneel.gov.br/api/3/action/datastore_search?resource_id=b1bd71e7-d0ad-4214-9053-cbd58e9564a7` — empreendimentos de geração por UF.
- **COPEL:** distribui energia para ~399 municípios do PR. Dados de qualidade de fornecimento (DEC/FEC) estão publicados na ANEEL. Não há API de consumo em tempo real aberta ao público.

---

## 9. Educação

> Cobertura: escolas públicas e privadas, matrículas, IDEB, desempenho no ENEM, infraestrutura escolar.

| Fonte | URL | Tipo de Acesso | Atualização | Formato | Dificuldade | Custo |
|-------|-----|---------------|-------------|---------|-------------|-------|
| INEP Microdados (Censo Escolar, ENEM, IDEB) | https://www.gov.br/inep/pt-br/acesso-a-informacao/dados-abertos/microdados | Download CSV (arquivos grandes) | Anual | CSV | 🟢 Fácil | Gratuito |
| INEP IDEB resultados | https://www.gov.br/inep/pt-br/areas-de-atuacao/pesquisas-estatisticas-e-indicadores/ideb | Download CSV | Bienal | CSV | 🟢 Fácil | Gratuito |
| SIMCAQ UFPR API | https://simcaq.c3sl.ufpr.br/api/v1/ | REST API (sem autenticação) | Anual | JSON | 🟢 Fácil | Gratuito |
| QEdu | https://www.qedu.org.br | Portal web (sem API pública) | Anual | HTML | 🔴 Difícil (scraping) | Gratuito |
| Base dos Dados (IDEB tratado) | https://basedosdados.org | BigQuery SQL API | Bienal | JSON/CSV | 🟡 Médio | Gratuito (limitado) |

**Notas técnicas:**
- **SIMCAQ API (recomendado para integração):** desenvolvida pela UFPR, fornece dados do Censo Escolar via API REST documentada.
  - Matrículas por estado PR: `GET https://simcaq.c3sl.ufpr.br/api/v1/enrollment?dims=state&filter=state:41`
  - Escolas por município PR: `GET https://simcaq.c3sl.ufpr.br/api/v1/school?dims=city&filter=state:41`
  - Inclui dados de infraestrutura (laboratório, biblioteca, acesso à internet, esgoto, etc.)
- **Censo Escolar microdados:** arquivos CSV anuais de ~500MB. Filtrar por `CO_UF = 41` para municípios do PR. Inclui 4.000+ variáveis.
- **IDEB 2023:** disponível para escolas, municípios e estado do PR, com séries históricas desde 2005.

---

## 10. Câmeras ao Vivo

> Cobertura: webcams urbanas (Curitiba e região), câmeras de rodovias (via parceiros), câmeras de clima.

| Fonte | URL | Tipo de Acesso | Atualização | Formato | Dificuldade | Custo |
|-------|-----|---------------|-------------|---------|-------------|-------|
| ClimaAoVivo.com.br (câmeras PR) | https://www.climaaovivo.com.br/pr/ | Web embed / streams MJPEG públicos | Tempo real | MJPEG / HLS | 🟡 Médio | Gratuito |
| Pictimo Curitiba | https://www.pictimo.com/brazil/curitiba | Embed webcam | Tempo real | MJPEG | 🟡 Médio | Gratuito |
| YouTube Live (webcams Curitiba) | https://www.youtube.com | YouTube Data API v3 (busca livestreams) | Tempo real | HLS | 🟡 Médio | Gratuito (quota 10k/dia) |
| Câmeras Você na RPC | App RPC (sem API pública) | App móvel / MJPEG embed | Tempo real | HLS/MJPEG | 🔴 Difícil | Gratuito (app) |
| Câmeras CET/SETRAN Curitiba | Portal interno (sem API pública) | Uso interno IPPUC/SETRAN | Tempo real | RTSP/MJPEG | 🔴 Difícil | — |

**Notas técnicas:**
- **ClimaAoVivo:** agrega dezenas de webcams paranaenses (postos de pedágio, pontos turísticos, câmeras de ski/neve). Streams MJPEG podem ser embeddados via `<img src="URL_stream">`. Verificar termos de uso antes de usar comercialmente.
- **YouTube API para livestreams:** `GET https://www.googleapis.com/youtube/v3/search?part=snippet&eventType=live&type=video&q=Curitiba+ao+vivo&key={API_KEY}` — retorna transmissões ao vivo ativas sobre Curitiba.
- Para câmeras de rodovias federais (PRF), não há API pública; o DER-PR possui câmeras via sistema OlhoVivo (acesso interno).

---

## 11. Dados Geoespaciais

> Cobertura: malha municipal (399 municípios), divisas, hidrografia, uso do solo, áreas protegidas, infraestrutura de saneamento.

| Fonte | URL | Tipo de Acesso | Atualização | Formato | Dificuldade | Custo |
|-------|-----|---------------|-------------|---------|-------------|-------|
| IBGE API Malhas — Municípios PR | https://servicodados.ibge.gov.br/api/v2/malhas/41/?resolucao=5&formato=application/vnd.geo%2Bjson | REST API (direto GeoJSON) | Anual | GeoJSON | 🟢 Fácil | Gratuito |
| IBGE API Localidades — Municípios PR | https://servicodados.ibge.gov.br/api/v1/localidades/estados/41/municipios | REST API | Variável | JSON | 🟢 Fácil | Gratuito |
| geodata-br (GitHub — municípios PR) | https://github.com/tbrugz/geodata-br | Download direto (raw GitHub) | Estático | GeoJSON | 🟢 Fácil | Gratuito |
| IAT-PR Mapas e Dados Espaciais | https://www.iat.pr.gov.br/Pagina/Mapas-e-Dados-Espaciais | Download portal + FTP geo_iat@200.189.114.112 | Variável | SHP/DXF/KML | 🟡 Médio | Gratuito |
| Paraná Interativo (ArcGIS REST) | https://paranainterativo.pr.gov.br/interativo/rest/services/ | ArcGIS REST API | Variável | JSON/GeoJSON | 🟡 Médio | Gratuito |
| MapBiomas (uso e cobertura) | https://plataforma.brasil.mapbiomas.org | GEE API + GCS download | Anual | GeoTIFF/GeoJSON | 🟡 Médio | Gratuito |
| TerraBrasilis INPE | https://terrabrasilis.dpi.inpe.br | WMS/WFS/REST OGC | Variável | GeoJSON/WFS | 🟡 Médio | Gratuito |

**Notas técnicas:**
- **IBGE GeoJSON direto (recomendado):**
  - Todos os municípios PR: `https://servicodados.ibge.gov.br/api/v2/malhas/41/?resolucao=5&formato=application/vnd.geo+json`
  - Município específico (ex: Curitiba = 4106902): `https://servicodados.ibge.gov.br/api/v2/malhas/4106902?resolucao=5&formato=application/vnd.geo+json`
- **Paraná Interativo (ArcGIS REST):** catálogo de serviços em `https://paranainterativo.pr.gov.br/interativo/rest/services/`. Contém camadas da SANEPAR (esgoto, abastecimento), SEDU (educação espacial), SESA (saúde espacial), IAT (meio ambiente) entre outros.
- **geodata-br raw GeoJSON:** `https://raw.githubusercontent.com/tbrugz/geodata-br/master/geojson/geojs-41-mun.json` — GeoJSON de todos os municípios do PR, leve e pronto para uso em Leaflet/Mapbox.

---

## 12. Defesa Civil

> Cobertura: desastres naturais registrados, alertas de chuva/enchente/deslizamento, histórico de ocorrências.

| Fonte | URL | Tipo de Acesso | Atualização | Formato | Dificuldade | Custo |
|-------|-----|---------------|-------------|---------|-------------|-------|
| S2iD — Sistema Integrado de Desastres | https://s2id.mi.gov.br | Portal web + download CSV | Variável (por evento) | CSV | 🟡 Médio | Gratuito |
| S2iD via Base dos Dados | https://basedosdados.org | BigQuery SQL API | Variável | JSON/CSV | 🟡 Médio | Gratuito (limitado) |
| Cemaden — Monitoramento | http://www2.cemaden.gov.br | Portal + RSS alertas | Tempo real | HTML/XML | 🔴 Difícil | Gratuito |
| Defesa Civil PR — SMS Alertas | SMS para 40199 (enviar CEP) | Push SMS (consumo, não publicação) | Tempo real | SMS | N/A | Gratuito |
| INMET Alertas Meteorológicos | https://alertas2.inmet.gov.br/ | Download JSON / Web | Diário | JSON/HTML | 🟡 Médio | Gratuito |

**Notas técnicas:**
- **S2iD:** sistema federal de registro de desastres. Municípios do PR que decretam situação de emergência ou calamidade pública registram aqui. Dados incluem: tipo de desastre (inundação, deslizamento, seca, granizo), danos humanos e materiais.
- **Cemaden alertas:** `http://www2.cemaden.gov.br/mapainterativo/` — mapa interativo com municípios em alerta. Não há API documentada; parsing do mapa via JSON embutido na página é tecnicamente viável.
- **INMET alertas JSON:** `GET https://apialerta.inmet.gov.br/v4/avisos` — retorna lista de alertas meteorológicos ativos com polígono GeoJSON de área afetada, nível de severidade (amarelo/laranja/vermelho), tipo e duração.
- O **40199** é um canal de alerta push (o cidadão se cadastra enviando o CEP), não uma fonte de dados para ingestão.

---

## 13. Qualidade da Água

> Cobertura: nível e qualidade de rios e reservatórios, abastecimento urbano SANEPAR, hidrologia da bacia Paraná.

| Fonte | URL | Tipo de Acesso | Atualização | Formato | Dificuldade | Custo |
|-------|-----|---------------|-------------|---------|-------------|-------|
| ANA Dados Abertos (hidroweb) | https://dadosabertos.ana.gov.br | REST API (CKAN) | Variável | CSV/GeoJSON | 🟢 Fácil | Gratuito |
| ANA Telemetria (nível rios — tempo real) | https://www.ana.gov.br/telemetria | Portal/download XML | Tempo real (1h) | XML/CSV | 🟡 Médio | Gratuito |
| ANA SNIRH Metadados | https://metadados.snirh.gov.br/geonetwork/ | Catálogo OGC/CSW | Variável | JSON/GeoJSON | 🟡 Médio | Gratuito |
| SANEPAR — Níveis Reservatórios | https://www.sanepar.com.br | Web scraping (exibe % ao vivo) | Diário | HTML | 🟡 Médio | Gratuito |
| SANEPAR — Saneamento Básico (GIS) | https://paranainterativo.pr.gov.br/interativo/rest/services/SANEPAR/SaneamentoBasico/MapServer | ArcGIS REST API | Variável | JSON/GeoJSON | 🟡 Médio | Gratuito |

**Notas técnicas:**
- **ANA Hidroweb API:** `GET https://www.ana.gov.br/ANA_Telemetrica/api/estacoes?codEstacao=&codRio=&codEstado=41` — retorna estações telemétricas no Paraná com latitude/longitude e dados de nível do rio.
- **ANA telemetria em tempo real:** dados de nível e vazão a cada 1 hora. Rios monitorados no PR incluem Paraná, Iguaçu, Tibagi, Ivaí, Piquiri, Cinzas.
- **SANEPAR Paraná Interativo:** camadas disponíveis incluem sistemas de abastecimento, ETAs, redes de distribuição. Endpoint base: `https://paranainterativo.pr.gov.br/interativo/rest/services/SANEPAR/SaneamentoBasico/MapServer/0/query?where=1=1&outFields=*&f=geojson`
- SANEPAR atende 344 dos 399 municípios paranaenses. Dados de % de armazenamento dos sistemas de abastecimento são exibidos no site mas sem API dedicada.

---

## 14. Dados Legislativos

> Cobertura: Assembleia Legislativa do Paraná (ALEP), Diário Oficial, dados socioeconômicos IPARDES, câmaras municipais.

| Fonte | URL | Tipo de Acesso | Atualização | Formato | Dificuldade | Custo |
|-------|-----|---------------|-------------|---------|-------------|-------|
| ALEP — API Dados Abertos | http://webservices.assembleia.pr.leg.br/api/public | REST API (GET, sem autenticação) | Tempo real | JSON | 🟢 Fácil | Gratuito |
| ALEP — Portal Transparência | https://transparencia.assembleia.pr.leg.br | Portal web + download XLSX | Variável | HTML/XLSX | 🟡 Médio | Gratuito |
| DIOE — Diário Oficial do Paraná | https://www.documentos.dioe.pr.gov.br/dioe/localizar.do | Download PDF + busca textual | Diário | PDF | 🟡 Médio | Gratuito |
| Portal Dados Abertos PR — IPARDES/BDEweb | https://www.dados.pr.gov.br | Download CSV/Excel | Anual | CSV/Excel | 🟢 Fácil | Gratuito |
| Câmaras Municipais (SAPL/e-Legislativo) | Cada município (padronizado SAPL/Interlegis) | REST API (Swagger — cada câmara) | Variável | JSON | 🟡 Médio | Gratuito |

**Notas técnicas:**
- **ALEP API (recomendado para integração):** base URL `http://webservices.assembleia.pr.leg.br/api/public`. Endpoints incluem:
  - `/proposicoes` — projetos de lei, resoluções, decretos
  - `/deputados` — lista e dados dos deputados estaduais
  - `/sessoes` — pautas e atas de sessões plenárias
  - `/votacoes` — resultados de votações nominais
- **DIOE:** Diário Oficial publicado diariamente (dias úteis). Licitações, contratos, nomeações, decretos do executivo estadual. API de busca fulltext disponível em `https://www.documentos.dioe.pr.gov.br/dioe/consultaDiarioEletronicoLista.do?action=consultar`.
- **Câmaras municipais SAPL:** cidades como Curitiba, Londrina, Maringá, Cascavel usam SAPL (Software de Apoio ao Processo Legislativo). API Swagger padrão em `{url_camara}/api/v1/` (ex: `https://camaradereadores.curitiba.pr.gov.br/api/v1/`).
- **Portal Dados Abertos PR (dados.pr.gov.br):** portal oficial do governo estadual com datasets de diversas secretarias — educação, saúde, segurança, transportes, meio ambiente. Integra com IPARDES (Instituto Paranaense de Desenvolvimento Econômico e Social).

---

## Matriz Resumida de Priorização

> Recomendação de ordem de integração para o MVP do dashboard C&C.

| Prioridade | Fonte | Categoria | Valor para C&C | Esforço |
|------------|-------|-----------|----------------|---------|
| ⭐⭐⭐ P1 | INMET API Estações | Clima | Alto — dados em tempo real | Baixo |
| ⭐⭐⭐ P1 | NASA FIRMS API | Meio Ambiente | Alto — focos de calor PR | Baixo |
| ⭐⭐⭐ P1 | InfoDengue API | Saúde | Alto — endemia PR | Baixo |
| ⭐⭐⭐ P1 | ONS Dados Abertos | Energia | Alto — geração Itaipu/PR | Baixo |
| ⭐⭐⭐ P1 | IBGE API Malhas | Geoespacial | Crítico — mapa base PR | Baixo |
| ⭐⭐⭐ P1 | ALEP API | Legislativo | Alto — único dado legislativo aberto PR | Baixo |
| ⭐⭐⭐ P1 | PRF Dados (CSV) | Segurança/Trânsito | Alto — acidentes rodovias federais PR | Baixo |
| ⭐⭐⭐ P1 | Gazeta do Povo RSS | Notícias | Alto — veículo líder PR | Muito baixo |
| ⭐⭐ P2 | DERAL/SEAB cotações | Economia/Agro | Alto — PR é maior produtor soja/frango | Médio |
| ⭐⭐ P2 | ANA Telemetria | Água | Médio-alto — nível rios PR | Médio |
| ⭐⭐ P2 | INPE BDQueimadas | Meio Ambiente | Médio — complementa FIRMS | Baixo |
| ⭐⭐ P2 | ANEEL Dados Abertos | Energia | Médio — solar DG PR | Baixo |
| ⭐⭐ P2 | SIMCAQ UFPR API | Educação | Médio — matrículas escolas PR | Baixo |
| ⭐⭐ P2 | CAGED Download | Economia | Médio — emprego formal PR | Baixo |
| ⭐⭐ P2 | S2iD Desastres | Defesa Civil | Médio — histórico PR | Médio |
| ⭐⭐ P2 | SANEPAR ArcGIS REST | Água/GIS | Médio — infraestrutura saneamento | Médio |
| ⭐ P3 | AQICN/WAQI | Meio Ambiente | Médio — qualidade ar cidades PR | Baixo |
| ⭐ P3 | MapBiomas | Meio Ambiente | Baixo para C&C (alto para relatórios) | Médio |
| ⭐ P3 | ClimaAoVivo câmeras | Câmeras | Médio — engajamento visual | Médio |
| ⭐ P3 | SINESP CSV | Segurança | Médio — criminalidade mensal | Baixo |
| ⭐ P3 | INEP Microdados | Educação | Baixo para C&C (alto para análise) | Alto |
| ⭐ P3 | DIOE PDF | Legislativo | Baixo para C&C (alto para compliance) | Alto |

---

## Lacunas Identificadas

As seguintes informações **não possuem fonte aberta disponível** para o Paraná e requerem acordos comerciais ou parcerias:

| Dado desejado | Situação | Alternativa possível |
|---------------|----------|---------------------|
| Nível de tráfego em tempo real (rodovias estaduais) | DER-PR sem API pública | HERE Traffic API / TomTom (pagos) |
| Câmeras de trânsito SETRAN/IPPUC em tempo real | Sistema interno (sem acesso público) | YouTube Live (webcams cidadãos) |
| Dados SIMEPAR em tempo real | Requer licença comercial | INMET + NASA FIRMS como alternativa |
| Leitos hospitalares em tempo real | SESA-PR sem API pública | OpenDataSUS (defasagem ~7 dias) |
| Ocorrências policiais (BO) em tempo real | COPOM/SESP sistema interno | PRF (apenas rodovias federais) |
| Consumo de energia por cidade (COPEL) | COPEL sem API pública | ONS (geração, não consumo distribuído) |
| Câmeras pedágios concessionárias | ECO Rodovias / Arteris — sem API pública | Parceria direta com concessionárias |

---

## Referências de URLs Críticas

```
# Clima
https://apitempo.inmet.gov.br/estacao/dados/{cod}/{dt_ini}/{dt_fim}
https://alertas2.inmet.gov.br/

# Saúde
https://info.dengue.mat.br/api/alertcity?geocode=4106902&disease=dengue&format=json
https://opendatasus.saude.gov.br

# Segurança
https://www.gov.br/prf/pt-br/acesso-a-informacao/dados-abertos/dados-abertos-da-prf

# Economia
https://celepar7.pr.gov.br/sima/cotdiap.asp
https://servicodados.ibge.gov.br/api/v1/pesquisas/38/indicadores/47001/resultados/41

# Meio Ambiente
https://firms.modaps.eosdis.nasa.gov/api/area/csv/{KEY}/VIIRS_SNPP_NRT/-54,-26.7,-48.0,-22.5/1
https://queimadas.dgi.inpe.br/api/focos/?pais_id=33&estado_id=41
https://api.waqi.info/feed/{city}/?token={token}

# Energia
https://dados.ons.org.br
s3://ons-aws-prod-opendata
https://dadosabertos.aneel.gov.br

# Educação
https://simcaq.c3sl.ufpr.br/api/v1/enrollment?dims=state&filter=state:41

# Geoespacial
https://servicodados.ibge.gov.br/api/v2/malhas/41/?resolucao=5&formato=application/vnd.geo+json
https://raw.githubusercontent.com/tbrugz/geodata-br/master/geojson/geojs-41-mun.json
https://paranainterativo.pr.gov.br/interativo/rest/services/
ftp://geo_iat:geo_iat@200.189.114.112

# Água
https://paranainterativo.pr.gov.br/interativo/rest/services/SANEPAR/SaneamentoBasico/MapServer
https://metadados.snirh.gov.br/geonetwork/

# Legislativo
http://webservices.assembleia.pr.leg.br/api/public
https://www.documentos.dioe.pr.gov.br/dioe/localizar.do
https://www.dados.pr.gov.br
```

---

*Documento gerado em 01/03/2026. Fontes verificadas e endpoints testados conforme disponibilidade pública. Sempre verificar termos de uso antes de usar comercialmente.*
