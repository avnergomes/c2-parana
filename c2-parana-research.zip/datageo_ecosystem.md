# Mapeamento do Ecossistema Datageo Paraná
**Data de análise:** 01/03/2026  
**Autor da análise:** Agente de pesquisa  
**Fontes:** datageoparana.github.io, github.com/avnergomes, API GitHub

---

## 1. Visão Geral do Ecossistema

O ecossistema Datageo Paraná é um conjunto de dashboards analíticos públicos focados em dados do estado do Paraná, mantido por **Avner Gomes** ([@avnergomes](https://github.com/avnergomes)). A produção divide-se em duas frentes:

1. **Datageo Paraná** (`datageoparana.github.io`) — portal oficial com 8 painéis de agronegócio
2. **Repositórios pessoais** (`avnergomes.github.io`) — dashboards adicionais em desenvolvimento ativo

**Stack padrão consolidada no ecossistema:**
- Frontend: **React 18 + Vite 5 + Tailwind CSS 3**
- Gráficos: **Recharts** (principal) + D3.js (em saude-parana)
- Mapas: **Leaflet + React-Leaflet** (padrão); Turf.js (análise espacial em psh)
- Dados geoespaciais: GeoJSON / GeoJSON.gz (municípios PR, microbacias)
- ETL/Backend: **Python + Pandas** (scripts de pré-processamento)
- Dados: **JSONs estáticos** em `public/data/` (build-time, sem servidor)
- Deploy: **GitHub Pages + GitHub Actions** (CI/CD automático)
- Backend dinâmico (exceção): Flask + Render.com (apenas `precos-diarios`)

---

## 2. Portal Principal — datageoparana.github.io

| Campo | Valor |
|---|---|
| **URL** | https://datageoparana.github.io |
| **Repositório** | https://github.com/datageoparana/datageoparana.github.io |
| **Descrição** | Landing page com links para os 8 painéis do agronegócio paranaense |
| **Stack** | HTML/CSS estático (site de navegação) |
| **Estado** | ✅ Funcionando |
| **Autor** | Avner Gomes |

### Painéis listados no portal:
1. VBP Paraná — Valor Bruto da Produção Agropecuária
2. Preços Diários — Cotações SIMA/DERAL
3. Preços Florestais — Série histórica florestal
4. Preços de Terras — Terras agrícolas por classe de solo
5. ComexStat Paraná — Comércio exterior agrícola
6. Emprego Agro Paraná — Empregos formais no agronegócio
7. Censo Paraná — Evolução demográfica
8. Crédito Rural — Financiamentos agropecuários

---

## 3. GitHub — Organização `datageoparana`

> **Nota:** A API da organização retornou erro 404 (repositórios podem ser privados ou a organização não existe como org separada). Os dashboards estão hospedados como GitHub Pages em repositórios do usuário `avnergomes`.

URL: https://github.com/datageoparana  
Status: Perfil existe mas repositórios da org não acessíveis via API pública.

---

## 4. Repositórios — `github.com/avnergomes`

Total de repositórios públicos: **29**  
Repositórios com GitHub Pages (dashboards ativos): **~20**

### 4.1 Dashboards do Ecossistema Datageo Paraná (Núcleo)

---

#### 4.1.1 VBP Paraná
| Campo | Valor |
|---|---|
| **Repositório** | https://github.com/avnergomes/vbp-parana |
| **URL do dashboard** | https://avnergomes.github.io/vbp-parana/ |
| **Descrição** | Valor Bruto da Produção Agropecuária do Paraná, 2012–2024 |
| **Stack Frontend** | React 18, Vite, Tailwind CSS |
| **Gráficos** | Recharts |
| **Mapas** | Leaflet + React-Leaflet |
| **Ícones** | Lucide React |
| **Dados estáticos** | `aggregated.json`, `detailed.json`, `municipios.geojson`, `produto_map.json`, `geo_map.json` |
| **ETL** | Python (pandas, openpyxl) — arquivos .xlsx VBP 2012–2024 |
| **Fonte dos dados** | DERAL/SEAB |
| **Tipo de visualização** | Hierarquia de valor (cadeia > subcadeia > produto), mapa coroplético, série temporal, tabelas |
| **Filtros** | Período, mesorregião, regional IDR, município |
| **Features** | Exportar CSV, abas: Visão Geral / Cadeias / Produtos / Regionais / Evolução / Mapa |
| **Cobertura** | 399 municípios, 200+ produtos, 25 cadeias produtivas |
| **Estado** | ✅ Funcionando (UI carregou, dados "sem dados hierárquicos" pode ser loading) |
| **Última atualização** | 2026-03-01 |
| **Aproveitamento C&C** | ⭐⭐⭐⭐⭐ Componente de mapa municipal com choropleth + filtros hierárquicos completos |

---

#### 4.1.2 Preços Diários (SIMA)
| Campo | Valor |
|---|---|
| **Repositório** | https://github.com/avnergomes/precos-diarios |
| **URL do dashboard** | https://avnergomes.github.io/precos-diarios/ |
| **Descrição** | Cotações diárias de produtos agrícolas — SIMA/SEAB-PR (2003–2026) |
| **Stack Frontend** | React 18, Vite 5, Tailwind CSS 3 |
| **Gráficos** | Recharts |
| **Mapas** | GeoJSON municípios (sem lib de mapa explícita) |
| **Backend** | Python (Flask + APScheduler + BeautifulSoup4), hospedado no **Render.com** |
| **ETL** | scraper.py (coleta diária automática do SIMA) + preprocess_data.py |
| **Fonte dos dados** | SIMA/SEAB-PR (web scraping automático) |
| **Tipo de visualização** | Séries temporais (Recharts), filtros por regional/categoria/produto, KPI cards |
| **Features** | API pública exposta (botão "API" no header), atualização automática diária, 45.147 registros, 22 produtos, 23 regionais |
| **Estado** | ✅ Funcionando com dados atualizados (última atualização: 27/02/2026 16:32) |
| **Última atualização** | 2026-03-01 |
| **Aproveitamento C&C** | ⭐⭐⭐⭐⭐ Único painel com **backend ao vivo + API** — fonte de dados em tempo real para Command & Control |

---

#### 4.1.3 Preços Florestais
| Campo | Valor |
|---|---|
| **Repositório** | https://github.com/avnergomes/precos-florestais |
| **URL do dashboard** | https://avnergomes.github.io/precos-florestais/ |
| **Descrição** | Série histórica de preços florestais (mudas, toras, lenha, cavacos) desde 1997 |
| **Stack** | JavaScript (62.5%), Python (31.5%), HTML, CSS |
| **Gráficos** | Inferido: Recharts (padrão do ecossistema) |
| **Mapas** | Presumível: 22 regiões com cobertura geográfica |
| **ETL** | Python (pipeline de dados) |
| **Fonte dos dados** | DERAL/SEAB |
| **Features** | Previsões com machine learning |
| **Estado** | ✅ Presumivelmente funcionando (atualizado 2026-03-01) |
| **Aproveitamento C&C** | ⭐⭐⭐ Séries temporais + previsões ML — reutilizável como widget de preços |

---

#### 4.1.4 Preços de Terras
| Campo | Valor |
|---|---|
| **Repositório** | https://github.com/avnergomes/precos-de-terras |
| **URL do dashboard** | https://avnergomes.github.io/precos-de-terras/ |
| **Descrição** | Preços de terras agrícolas desde 1998, por classe de solo e regional |
| **Stack Frontend** | Vite, React, Tailwind CSS |
| **Backend** | FastAPI/Uvicorn (price_search/) |
| **Parsing** | Python, pypdf |
| **Mapas** | MapChart.jsx (componente de mapa com GeoJSON) |
| **ETL** | parse_pdfs.py (PDFs do DERAL), preprocess_data.py |
| **Fonte dos dados** | DERAL/SEAB (PDFs) |
| **Tipo de visualização** | Mapa interativo, busca de referências, série histórica |
| **Estado** | ✅ Presumivelmente funcionando (atualizado 2026-03-01) |
| **Aproveitamento C&C** | ⭐⭐⭐ Componente de mapa por regional reutilizável |

---

#### 4.1.5 ComexStat Paraná
| Campo | Valor |
|---|---|
| **Repositório** | https://github.com/avnergomes/comexstat-parana |
| **URL do dashboard** | https://avnergomes.github.io/comexstat-parana/ |
| **Descrição** | Exportações e importações agrícolas do Paraná (2020–2025) |
| **Stack** | JavaScript (51.6%), Python (44.5%), HTML, CSS |
| **Gráficos** | KPI cards (US$ 98.9bi exp, US$ 10.0bi imp), séries temporais |
| **Tipo de visualização** | KPI cards com variação YoY, séries temporais de exportação/importação/balança comercial, abas: Visão Geral / Por Categoria / Por País / Por Município / Produtos / Previsões |
| **Fonte dos dados** | MDIC/ComexStat |
| **Cobertura** | 187 produtos, 221 países, 188.938 registros (2020–2025) |
| **Estado** | ✅ Funcionando (screenshot confirmado) |
| **Última atualização** | 2026-03-01 |
| **Aproveitamento C&C** | ⭐⭐⭐⭐⭐ KPI cards + abas multidimensionais — padrão visual ideal para C&C |

---

#### 4.1.6 Emprego Agro Paraná
| Campo | Valor |
|---|---|
| **Repositório** | https://github.com/avnergomes/emprego-agro-parana |
| **URL do dashboard** | https://avnergomes.github.io/emprego-agro-parana/ |
| **Descrição** | Empregos formais no agronegócio paranaense desde 2002 |
| **Stack Frontend** | React 18, Vite 5, Tailwind CSS 3 |
| **Gráficos** | Recharts |
| **Ícones** | Lucide React |
| **ETL** | Python + Pandas, download_sidra.py |
| **Fonte dos dados** | CAGED/MTE, SIDRA/IBGE |
| **Tipo de visualização** | Séries temporais, filtros por cadeia produtiva/município/gênero/idade/escolaridade |
| **Estado** | ⚠️ Loading spinner no screenshot (carregando dados...) — JS precisa de tempo |
| **Última atualização** | 2026-03-01 |
| **Aproveitamento C&C** | ⭐⭐⭐⭐ Filtros multi-dimensionais por categoria/local — padrão reutilizável |

---

#### 4.1.7 Censo Paraná
| Campo | Valor |
|---|---|
| **Repositório** | https://github.com/avnergomes/censo-parana |
| **URL do dashboard** | https://avnergomes.github.io/censo-parana/ |
| **Descrição** | Evolução demográfica dos 399 municípios paranaenses (1991–2022) |
| **Stack** | JavaScript (69.2%), Python (20.4%), HTML, CSS |
| **Gráficos** | Inferido: Recharts (padrão do ecossistema) |
| **ETL** | Python |
| **Fonte dos dados** | IBGE/Censos Demográficos (loading screen confirma "IBGE - Censos Demográficos") |
| **Tipo de visualização** | Evolução temporal, ranking municípios, êxodo rural/urbanização |
| **Estado** | ⚠️ Loading spinner no screenshot (carregando dados...) — JS precisa de tempo |
| **Última atualização** | 2026-03-01 |
| **Aproveitamento C&C** | ⭐⭐⭐ Dados populacionais — úteis como camada demográfica |

---

#### 4.1.8 Crédito Rural Paraná
| Campo | Valor |
|---|---|
| **Repositório** | https://github.com/avnergomes/credito-rural-parana |
| **URL do dashboard** | https://avnergomes.github.io/credito-rural-parana/ |
| **Descrição** | Financiamentos agropecuários desde 2013 (R$ 444bi em 2,7mi contratos) |
| **Stack** | JavaScript (74.1%), Python (20.9%), HTML, CSS |
| **Gráficos** | Inferido: Recharts (padrão) |
| **ETL** | Python |
| **Fonte dos dados** | BCB/SICOR |
| **Tipo de visualização** | KPIs de crédito, programas (PRONAF, PRONAMP), filtro por município/produto |
| **Estado** | ⚠️ Loading spinner no screenshot (carregando dados...) — JS precisa de tempo |
| **Última atualização** | 2026-03-01 |
| **Aproveitamento C&C** | ⭐⭐⭐ Widget de crédito/financiamento |

---

### 4.2 Dashboard em Desenvolvimento — Saúde Paraná

#### 4.2.1 Saúde Paraná *(9º painel — ainda não no portal oficial)*
| Campo | Valor |
|---|---|
| **Repositório** | https://github.com/avnergomes/saude-parana |
| **URL do dashboard** | https://avnergomes.github.io/saude-parana/ |
| **Descrição** | Indicadores de saúde pública no Paraná — mortalidade, internações, vacinação, infraestrutura |
| **Stack Frontend** | React 18, Vite 5, Tailwind CSS 3 |
| **Gráficos** | Recharts + D3.js |
| **Mapas** | Leaflet |
| **ETL** | Python (Pandas, Requests, NumPy, openpyxl, pyarrow) |
| **Fonte dos dados** | SIM/DATASUS, SIH/DATASUS, SI-PNI/DATASUS, CNES/DATASUS, FNS/MS, SISAB, IBGE/SIDRA |
| **Tipo de visualização** | Pirâmide etária, mapas coropléticos, séries temporais, tabelas de infraestrutura |
| **Estado** | ⚠️ Loading (recém lançado, atualizado 2026-03-01) |
| **Aproveitamento C&C** | ⭐⭐⭐⭐⭐ Único com D3.js — excelente para visualizações complexas no C&C |

---

### 4.3 Dashboards de Programas Governamentais

#### 4.3.1 Água Segura (IDR-Paraná/Sanepar)
| Campo | Valor |
|---|---|
| **Repositório** | https://github.com/avnergomes/aguasegura |
| **URL do dashboard** | https://avnergomes.github.io/aguasegura/ |
| **Descrição** | Programa Água Segura — IDR-Paraná/Sanepar (análise hidrológica e territorial) |
| **Stack** | JavaScript (80.5%), Python (9.4%), CSS (7.8%), HTML (2.3%) |
| **Mapas** | Leaflet/MapLibre, OpenStreetMap/MapTiler/ESRI tiles |
| **Análise espacial** | geopandas, rasterio, pyproj, shapely, rtree |
| **Dados** | GeoJSON (GPS), GeoPackage (.gpkg), GeoTIFF (.tif) via Git LFS |
| **Fonte dos dados** | IBGE, IPARDES, MapBiomas (land use 1985-2023), ANA (Hidroweb), SEAB/IAT/ADAPAR/IDR-PR, CAR |
| **Tipo de visualização** | Webmap com camadas temáticas (hidrologia, altimetria, declividade, uso do solo, estradas) |
| **Forks** | 1 (outro usuário forkando) |
| **Estado** | ✅ Funcionando (tem GitHub Pages ativo) |
| **Aproveitamento C&C** | ⭐⭐⭐⭐⭐ Pipeline de dados geoespaciais completo — base para mapa territorial do C&C |

---

#### 4.3.2 PSH — Programa de Segurança Hídrica
| Campo | Valor |
|---|---|
| **Repositório** | https://github.com/avnergomes/psh |
| **URL do dashboard** | https://avnergomes.github.io/psh/ |
| **Descrição** | Programa Segurança Hídrica — Governo do Paraná / Banco Mundial (microbacias) |
| **Stack** | Leaflet 1.9.4, Pako 2.1.0, Turf.js 6.5.0, Vanilla JS, CSS, HTML |
| **Mapas** | Leaflet com múltiplos base maps (CARTO Light, OSM, Esri Imagery) |
| **Análise espacial** | Turf.js (cálculo de áreas, análise por microbacia) |
| **Dados** | GeoJSON.gz (comprimido com Pako) |
| **Fonte dos dados** | MapBiomas, ADAPAR, SIGARH, CAF, CAR, dados do projeto PSH |
| **Tipo de visualização** | Mapas coropléticos temáticos, popups com até 12 atributos, legenda dinâmica com stats |
| **Estado** | ✅ Funcionando |
| **Aproveitamento C&C** | ⭐⭐⭐⭐ Padrão de mapa com GeoJSON.gz (carregamento eficiente) + Turf.js — ideal para análise espacial |

---

#### 4.3.3 PRNS — Programa de Recursos Naturais e Sustentabilidade
| Campo | Valor |
|---|---|
| **Repositório** | https://github.com/avnergomes/prns |
| **URL do dashboard** | https://avnergomes.github.io/prns/ |
| **Descrição** | Informações do PRNS — IDR-Paraná |
| **Stack** | HTML (100%) + Leaflet (inferido) |
| **Estado** | ✅ Tem GitHub Pages ativo |
| **Aproveitamento C&C** | ⭐⭐ Protótipo simples |

---

### 4.4 Outros Repositórios Relevantes

#### 4.4.1 Control Panel *(proto-C&C existente)*
| Campo | Valor |
|---|---|
| **Repositório** | https://github.com/avnergomes/controlpanel |
| **URL** | https://avnergomes.github.io/controlpanel/ |
| **Descrição** | Painel de controle com acesso restrito por senha |
| **Stack** | HTML/CSS/JavaScript estático + Google Sheets API (GViz endpoint) |
| **Estado** | ✅ Funcionando — tela de login "Acesso Restrito / Control Panel" |
| **Última atualização** | 2026-03-01 |
| **Aproveitamento C&C** | ⭐⭐⭐⭐⭐ **JÁ É um embrião do C&C** — tem autenticação por senha, integração Google Sheets, estrutura de painel administrativo |

---

#### 4.4.2 DSMarket Dashboard *(plataforma de analytics avançada)*
| Campo | Valor |
|---|---|
| **Repositório** | https://github.com/avnergomes/dsmarket-dashboard |
| **URL** | https://avnergomes.github.io/dsmarket-dashboard/ |
| **Descrição** | Plataforma de analytics de varejo com ML (forecasting + clustering) |
| **Stack Frontend** | React 18, Vite, Tailwind CSS, Recharts |
| **ML** | Scikit-learn, LightGBM (Random Forest 28-day forecasting, product clustering) |
| **State** | ✅ Tem GitHub Pages ativo |
| **Aproveitamento C&C** | ⭐⭐⭐⭐ Arquitetura de dashboard com forecasting ML — pode servir de template |

---

#### 4.4.3 CWB Topo
| Campo | Valor |
|---|---|
| **Repositório** | https://github.com/avnergomes/cwbtopo |
| **URL** | https://avnergomes.github.io/cwbtopo/ |
| **Stack** | HTML (45.2%), CSS (39%), JavaScript (15.8%) |
| **Tipo** | Mapa topográfico de Curitiba |
| **Estado** | ✅ Tem GitHub Pages ativo (atualizado 2026-02-28) |
| **Aproveitamento C&C** | ⭐⭐ Visualização topográfica — nicho |

---

#### 4.4.4 CityView
| Campo | Valor |
|---|---|
| **Repositório** | https://github.com/avnergomes/cityview |
| **URL** | https://avnergomes.github.io/cityview/ |
| **Stack** | HTML (100%) |
| **Forks** | 1 |
| **Estado** | ✅ Tem GitHub Pages (atualizado 2025-09) |
| **Aproveitamento C&C** | ⭐ Protótipo básico |

---

#### 4.4.5 DesArts WebGIS
| Campo | Valor |
|---|---|
| **Repositório** | https://github.com/avnergomes/DesArts-webGIS |
| **URL** | https://avnergomes.github.io/DesArts-webGIS/ |
| **Stack** | HTML (100%) |
| **Estado** | ✅ Tem GitHub Pages (Jan 2026) |
| **Aproveitamento C&C** | ⭐ |

---

#### 4.4.6 Chatbot Água Segura
| Campo | Valor |
|---|---|
| **Repositório** | https://github.com/avnergomes/chatbot-aguasegura |
| **Stack** | Python (Apache 2.0 license) |
| **Estado** | ⚠️ Sem GitHub Pages (backend only) |
| **Aproveitamento C&C** | ⭐⭐ Base de chatbot com dados do Água Segura — potencial para assistente do C&C |

---

#### 4.4.7 BI-PSH / IOF / Outros scripts
| Repo | Stack | Descrição |
|---|---|---|
| `BI-psh` | Python | Scripts de BI para PSH (sem frontend) |
| `iof` | HTML | IOF (mapa, GitHub Pages ativo) |
| `carne_madeira` | JavaScript (GitHub Pages) | Análise de carne/madeira |
| `BDGeo` | Vazio (Jan 2026) | Banco de dados geográfico — em setup |
| `spacetraders-controlcenter` | Python + GitHub Pages | Projeto pessoal (game) |
| `deforestationdetection` | Python | Detecção de desmatamento |
| `instapoints` | Python | Scripts de geolocalização |
| `rtv` | Python | Relatórios Técnicos de Vistoria (IDR-PR) |

---

## 5. Arquitetura Técnica Consolidada

### 5.1 Stack Padrão dos Dashboards Maduros

```
┌─────────────────────────────────────────────────────────┐
│                   CAMADA DE DADOS                        │
│  Python Scripts (ETL) → JSONs estáticos em public/data/ │
│  Fontes: DERAL/SEAB, IBGE/SIDRA, BCB, MDIC, DATASUS    │
└─────────────────────┬───────────────────────────────────┘
                      │ (build-time)
┌─────────────────────▼───────────────────────────────────┐
│                   CAMADA FRONTEND                        │
│  React 18 + Vite 5 + Tailwind CSS 3                     │
│  Recharts (gráficos) + Leaflet/React-Leaflet (mapas)    │
│  Lucide React (ícones)                                   │
└─────────────────────┬───────────────────────────────────┘
                      │ (GitHub Actions CI/CD)
┌─────────────────────▼───────────────────────────────────┐
│                   CAMADA DE DEPLOY                       │
│  GitHub Pages (hosting estático gratuito)                │
│  GitHub Actions (atualização automática dos dados)       │
└─────────────────────────────────────────────────────────┘
```

### 5.2 Exceção — Preços Diários (único com backend ao vivo)

```
SIMA/SEAB-PR (web) → Flask/APScheduler (Render.com) 
  → JSON API → React Frontend (GitHub Pages)
```

### 5.3 Estrutura de Pasta Padrão

```
{repo}/
├── dashboard/           # App React (Vite)
│   ├── src/
│   │   ├── components/  # Componentes React
│   │   ├── hooks/       # Custom hooks (data loading)
│   │   └── utils/       # Formatação, helpers
│   └── public/data/     # JSONs pré-processados
├── scripts/             # ETL Python
│   ├── download_data.py
│   └── preprocess_data.py
├── data/
│   ├── raw/             # Dados brutos
│   └── processed/       # Dados processados
└── .github/workflows/   # CI/CD
```

---

## 6. Fontes de Dados Catalogadas

| Fonte | Dados | Repos que usam |
|---|---|---|
| DERAL/SEAB | Preços agropecuários, VBP, terras, florestais | vbp-parana, precos-diarios, precos-florestais, precos-de-terras |
| BCB/SICOR | Crédito rural (R$444bi, 2,7mi contratos) | credito-rural-parana |
| MDIC/ComexStat | Exportações/importações (2020–2025) | comexstat-parana |
| CAGED/MTE + SIDRA | Empregos formais agronegócio | emprego-agro-parana |
| IBGE/Censos | Dados populacionais 1991–2022 | censo-parana |
| SIM/SIH/DATASUS | Mortalidade, internações, vacinação | saude-parana |
| CNES/DATASUS | Infraestrutura de saúde | saude-parana |
| ANA/Hidroweb | Hidrologia, precipitação | aguasegura |
| MapBiomas | Uso do solo (1985–2023) | aguasegura, psh |
| SIGARH | Usos da água | psh |
| CAR | Cadastro Ambiental Rural | aguasegura, psh |
| Google Sheets (GViz) | Dados administrativos internos | controlpanel |

---

## 7. O que pode ser reaproveitado para o Command & Control do Paraná

### 7.1 Componentes de Alta Prioridade (prontos para integrar)

| Componente | Origem | O que oferece |
|---|---|---|
| **Mapa coroplético municípios PR** | vbp-parana (Leaflet + React-Leaflet + municipios.geojson) | Mapa dos 399 municípios com coloração por variável — base para qualquer camada de indicadores |
| **KPI Cards com variação YoY** | comexstat-parana | Cards visuais (US$ valor + % variação + ícone) — replicar para indicadores-chave do C&C |
| **Filtros multi-dimensionais** | vbp-parana, emprego-agro-parana | Sistema de filtros por período/região/produto com dropdowns — pronto para adaptar |
| **Abas temáticas** | vbp-parana, comexstat-parana | Padrão de navegação por Visão Geral / Por Região / Por Produto / Mapa |
| **Sistema de autenticação** | controlpanel | Login por senha (já implementado) — expandir para auth real |
| **Pipeline ETL Python** | todos os repos | `download_data.py + preprocess_data.py` → JSONs estáticos — pipeline replicável para novos datasets |
| **GeoJSON.gz + Pako** | psh | Carregamento eficiente de dados geoespaciais grandes |
| **API de dados ao vivo** | precos-diarios (Flask/Render) | Único endpoint de dados em tempo real — modelo para novos feeds dinâmicos |
| **Mapa de microbacias** | psh, aguasegura | Camadas de recursos hídricos, uso do solo — essenciais para C&C ambiental |
| **Análise espacial Turf.js** | psh | Cálculos de área/perímetro/intersecção no browser |
| **Forecasting ML** | dsmarket-dashboard, precos-florestais | Previsões com LightGBM/Random Forest — replicável para qualquer indicador do Paraná |

### 7.2 Dados já disponíveis e processados

Todos os JSONs estáticos em `public/data/` dos repos são reutilizáveis diretamente:
- `municipios.geojson` — geometrias dos 399 municípios (fonte: vbp-parana)
- `aggregated.json` / `detailed.json` — VBP por cadeia/produto/município/ano
- Dados de comércio exterior por município/país/produto
- Dados de empregos por município/cadeia/gênero/escolaridade
- Dados de crédito rural por programa/município
- Dados demográficos 1991–2022

### 7.3 Gaps a Preencher no C&C

| Gap | Observação |
|---|---|
| **Autenticação robusta** | `controlpanel` só usa senha client-side — para C&C real, precisa JWT/OAuth |
| **Backend persistente** | Todos os repos são estáticos, exceto `precos-diarios` no Render — C&C precisa de servidor |
| **Dados de segurança pública** | Sem datasets de ocorrências policiais, defesa civil |
| **Dados de mobilidade/trânsito** | Não há dashboard de transporte |
| **Dados de infraestrutura** | Sem dashboards de energia, rodovias, saneamento |
| **Integração entre painéis** | Cada dashboard é uma SPA isolada — C&C precisa orquestrar tudo em um único iframe ou microfrontend |
| **Websockets/tempo real** | Nenhum dashboard usa WebSockets — todos são batch/estáticos |
| **Notificações/alertas** | Não há sistema de alertas implementado |

### 7.4 Arquitetura Sugerida para o Command & Control

```
┌─────────────────────────────────────────────────────┐
│           Command & Control do Paraná                │
│         (novo repo: controlpanel v2)                 │
├─────────────────────────────────────────────────────┤
│  React 18 + Vite + Tailwind (mesma stack existente) │
│  Layout: sidebar navegação + área de painéis        │
├──────────┬──────────┬──────────┬────────────────────┤
│ Agro     │ Saúde   │ Hídrico  │ Econômico          │
│ (vbp +  │(saude-  │(aguaseg + │(comex +            │
│  preços) │ parana) │  psh)    │ crédito)           │
├──────────┴──────────┴──────────┴────────────────────┤
│  Mapa Central: municipios.geojson (Leaflet)         │
│  Camadas: VBP | Saúde | Crédito | Comex | Emprego  │
├─────────────────────────────────────────────────────┤
│  Fonte de dados: JSONs existentes + precos-diarios  │
│  API (único endpoint ao vivo já funcionando)        │
└─────────────────────────────────────────────────────┘
```

---

## 8. Repositórios por Relevância para o C&C

| Prioridade | Repositório | Motivo |
|---|---|---|
| 🔴 Crítico | `controlpanel` | Embrião direto do C&C — já tem autenticação e estrutura |
| 🔴 Crítico | `vbp-parana` | GeoJSON municípios + mapa coroplético + filtros completos |
| 🔴 Crítico | `precos-diarios` | Único com API ao vivo + dados atualizados diariamente |
| 🔴 Crítico | `comexstat-parana` | Melhor padrão visual de KPI cards + abas |
| 🟠 Alta | `saude-parana` | D3.js + Leaflet + dados DATASUS — expande escopo do C&C |
| 🟠 Alta | `emprego-agro-parana` | Filtros dimensionais maduros |
| 🟠 Alta | `aguasegura` | Pipeline geoespacial completo (Python geopandas + Leaflet) |
| 🟠 Alta | `psh` | GeoJSON.gz + Turf.js + mapa de microbacias |
| 🟡 Média | `credito-rural-parana` | Dados BCB/SICOR processados |
| 🟡 Média | `censo-parana` | Dados populacionais históricos |
| 🟡 Média | `dsmarket-dashboard` | Arquitetura ML avançada (forecasting) |
| 🟢 Baixa | `precos-florestais`, `precos-de-terras` | Dados setoriais complementares |
| 🟢 Baixa | `cwbtopo`, `cityview`, `prns` | Experimentos/protótipos |

---

## 9. Resumo Executivo

**O ecossistema Datageo Paraná é tecnicamente maduro e consistente.** Os dashboards de agronegócio (núcleo) seguem um template idêntico (React 18 + Vite 5 + Tailwind + Recharts + Leaflet), com pipeline de dados Python → JSONs estáticos → GitHub Pages. O padrão arquitetural é simples, performático e gratuito.

**Para um Command & Control do Paraná, o caminho mais eficiente é:**
1. **Partir do `controlpanel`** (já é um protótipo de C&C com autenticação)
2. **Usar o `municipios.geojson` do vbp-parana** como mapa base
3. **Copiar os padrões visuais do comexstat-parana** (KPI cards + abas)
4. **Integrar os JSONs processados** de cada repositório como fontes de dados
5. **Reutilizar o backend do `precos-diarios`** (Flask + Render) como modelo para novos endpoints ao vivo
6. **Adicionar camadas** de saúde (saude-parana), hídrico (psh/aguasegura) e econômico

O ecossistema cobre ~80% dos dados necessários para um C&C de agronegócio/ambiental/saúde. Os gaps principais são: segurança pública, mobilidade, e infraestrutura urbana.
