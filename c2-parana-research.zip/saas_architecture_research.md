# Arquitetura SaaS com GitHub Pages — Pesquisa de Melhores Práticas e Ferramentas

> **Data da pesquisa:** Março 2026  
> **Contexto:** SaaS com frontend estático hospedado no GitHub Pages, sem servidor próprio.

---

## Sumário Executivo

Construir um SaaS completamente sobre GitHub Pages é viável e cada vez mais comum no ecossistema Jamstack. A estratégia central é delegar todas as funcionalidades dinâmicas (auth, pagamentos, banco de dados, cron jobs) a serviços externos gerenciados (BaaS), enquanto o frontend permanece puramente estático. Este documento detalha as melhores opções para cada componente, com foco no contexto brasileiro.

---

## 1. Autenticação para GitHub Pages (Site Estático)

### Problema Fundamental

GitHub Pages serve apenas arquivos estáticos. Toda autenticação precisa ser executada **client-side via SDK JavaScript**, com tokens armazenados no browser (localStorage/sessionStorage). O servidor de autenticação é gerenciado pelo provedor externo (Firebase, Supabase, etc.).

**Cuidado importante:** O Firebase Auth usa iframes e cookies de terceiros para o fluxo OAuth (`signInWithPopup`/`signInWithRedirect`). Com navegadores modernos bloqueando cookies de terceiros por padrão (Chrome, Safari), o domínio `*.firebaseapp.com` pode ser tratado como terceiro em relação ao seu `*.github.io`, causando falhas de login. A solução é hospedar o handler `/auth/handler` no mesmo domínio — o que exige um domínio customizado com configuração DNS específica. Essa é a limitação mais crítica do Firebase Auth em GitHub Pages com `github.io`.

---

### 1.1 Firebase Auth (Google, Email/Senha)

**Como funciona em sites estáticos:**
- Inclua o SDK Firebase via CDN ou npm bundle
- Inicialize com `firebaseConfig` (chaves públicas — seguras para expor no frontend)
- Use `signInWithPopup(auth, provider)` para Google OAuth
- Use `signInWithEmailAndPassword()` para email/senha
- O SDK gerencia tokens JWT automaticamente no localStorage

**Exemplo mínimo:**
```javascript
import { initializeApp } from "firebase/app";
import { getAuth, signInWithPopup, GoogleAuthProvider } from "firebase/auth";

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const provider = new GoogleAuthProvider();

// Login com Google (popup — requer cookies de terceiros)
signInWithPopup(auth, provider).then((result) => {
  const user = result.user;
  const token = await user.getIdToken(); // JWT para verificar no BaaS
});
```

**Planos e preços (2026):**
- **Spark (Gratuito):** 50.000 MAUs, email/senha, Google OAuth, GitHub, etc.
- **Blaze (Pay-as-you-go):** $0.0055 por MAU após 50.000; cobra apenas pelo excedente.

**Prós:**
- Tier gratuito extremamente generoso (50k MAUs)
- SDK muito maduro e documentado
- Integra nativamente com Firestore, Storage, Cloud Functions
- Suporte a múltiplos provedores OAuth (Google, GitHub, Microsoft, etc.)
- Funciona 100% client-side sem backend

**Contras:**
- **Problema crítico com cookies de terceiros em GitHub Pages** — `signInWithPopup` falha em navegadores com cookies de terceiros bloqueados quando o site está em `*.github.io` (sem domínio customizado)
- Requer domínio customizado + configuração do `authDomain` para funcionar corretamente
- Workaround: usar `signInWithCredential` com Google Identity Services SDK separado (mais complexo)
- Vendor lock-in no ecossistema Google
- Projeto pode ser pausado se inativo (Spark tier)

**Recomendação para GitHub Pages:** Use Firebase Auth **somente se tiver domínio customizado** configurado. Caso contrário, prefira Supabase ou Clerk.

**Fonte:** [Firebase Auth Documentation](https://firebase.google.com/docs/auth/web/github-auth), [GitHub Issue sobre cookies de terceiros](https://github.com/firebase/firebaseui-web/issues/444)

---

### 1.2 Supabase Auth

**Como funciona em sites estáticos:**
- Use o SDK `@supabase/supabase-js` (disponível via CDN ou npm bundle)
- A `ANON_KEY` (chave pública) pode ser exposta no frontend — é projetada para isso
- Auth gerenciado pelo Supabase com políticas de Row Level Security (RLS) no banco

**Exemplo mínimo:**
```javascript
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  'https://SEU_PROJETO.supabase.co',
  'SUA_ANON_KEY'  // chave pública — segura para expor
)

// Login com email/senha
const { data, error } = await supabase.auth.signInWithPassword({
  email: 'user@example.com',
  password: 'password'
})

// Login com Google OAuth
const { data } = await supabase.auth.signInWithOAuth({
  provider: 'google',
  options: { redirectTo: 'https://seusite.github.io/callback' }
})
```

**Planos e preços (2026):**

| Recurso | Free | Pro ($25/mês) |
|---|---|---|
| MAUs (auth) | 50.000 | 100.000 incluídos |
| Banco de dados | 500 MB | 8 GB |
| File storage | 1 GB | 100 GB |
| Edge Functions | 500k invocações/mês | 2M incluídos |
| Projetos ativos | 2 | Ilimitado |
| Inatividade | Pausa após 7 dias | Sem pausa |
| MAU excedente | - | $0.00325/MAU |

**Atenção:** Projetos free são **pausados automaticamente após 7 dias de inatividade**. Para projetos de produção, configure um cron job que pinga o banco periodicamente, ou upgrade para Pro.

**Prós:**
- 50.000 MAUs gratuitos — mais generoso que Auth0
- Auth + banco de dados + storage + edge functions em um único serviço
- Sem problemas de cookies de terceiros — usa PKCe flow com redirecionamento
- Open source (pode self-hostar)
- Row Level Security (RLS) permite controle de acesso granular direto no banco
- Funciona nativamente com `github.io` sem configurações especiais

**Contras:**
- Free tier pausa após 7 dias de inatividade (problemático para projetos de baixo tráfego)
- Banco de dados compartilhado no free tier (menor performance)
- Menos polish no UI de auth comparado ao Clerk

**Recomendação para GitHub Pages:** **Melhor opção geral** para SaaS estático. Elimina a necessidade de múltiplos serviços (auth + banco + storage + functions).

**Fonte:** [Supabase Auth Docs](https://supabase.com/docs/guides/auth), [Supabase Pricing 2026](https://uibakery.io/blog/supabase-pricing), [No-build static site com Supabase](https://willschenk.com/howto/2024/no_build_static_site_that_used_supabase/)

---

### 1.3 Auth0

**Como funciona:**
- SDK `@auth0/auth0-spa-js` para SPAs/sites estáticos
- Fluxo PKCE (sem necessidade de client secret)
- Suporte a regras/actions para customizar claims JWT

**Planos e preços (2026) — Auth0 atualizou o free tier:**

| Recurso | Free | Essentials ($35/mês) |
|---|---|---|
| MAUs | 25.000 | 500 MAUs (+por MAU) |
| Social connections | Ilimitadas | Ilimitadas |
| Custom domain | Sim (requer cartão) | Sim |
| Passwordless | Sim | Sim |
| Organizations | 5 | 10 |
| MFA | Básico | Avançado |
| Log retention | 2 dias | 7 dias |

**Atenção:** O tier Essentials custa $35/mês mas inclui **apenas 500 MAUs**. Crescer além do free tier é significativamente caro.

**Prós:**
- 25.000 MAUs gratuitos (segundo melhor depois de Supabase/Firebase)
- Suporte enterprise (SSO, SCIM, compliance) no free tier
- Muito maduro e amplamente usado

**Contras:**
- Pricing muito caro após o free tier ($35/mês por apenas 500 MAUs extras)
- Mais complexo de configurar que Clerk ou Supabase
- 2 dias de log retention no free tier é muito limitado

**Fonte:** [Auth0 Pricing](https://auth0.com/pricing), [Reddit Auth0 Free Tier Discussion](https://www.reddit.com/r/webdev/comments/1khvbw6/)

---

### 1.4 Clerk

**Como funciona:**
- Componentes React/Next.js prontos (`<SignIn/>`, `<UserButton/>`)
- Para sites estáticos sem React: SDK JS básico
- Ideal para apps React/Next.js — menos natural para HTML puro

**Planos e preços (2026):**

| Recurso | Free (Hobby) | Pro ($25/mês) |
|---|---|---|
| MAUs | 10.000 | 10.000 incluídos |
| MAOs (Organizations) | 100 | 100 incluídos |
| MAU excedente | - | $0.02/MAU |
| MAO excedente | - | $1/MAO |
| Custom domain | Não | Sim |
| Clerk branding | Sim | Removível |
| SSO enterprise | Não | 1 conexão incluída |

**Scaling costs:** Com 100.000 MAUs → $25 + (90.000 × $0.02) = **$1.825/mês**. Compare com Supabase a $25/mês para o mesmo volume.

**Prós:**
- **Melhor DX (Developer Experience)** — componentes pré-construídos de alta qualidade
- Integração nativa com Next.js App Router, autenticação em edge middleware
- B2B features (organizações, roles) no free tier
- UI de auth mais polida visualmente

**Contras:**
- Apenas 10.000 MAUs gratuitos (menor que Firebase, Supabase, Auth0)
- Escala de forma muito cara — $1.825/mês para 100k usuários
- Componentes UI são otimizados para React — funcionalidade reduzida em HTML puro
- Para GitHub Pages com HTML estático, integração é mais trabalhosa

**Recomendação:** Excelente para Next.js/React SaaS com poucos usuários e necessidades B2B. Para escala ou orçamento limitado, Supabase é superior.

**Fonte:** [Clerk Pricing Guide](https://supertokens.com/blog/clerk-pricing-the-complete-guide), [Clerk vs Supabase Auth Comparison](https://www.getmonetizely.com/articles/clerk-vs-supabase-auth-how-to-choose-the-right-authentication-service-for-your-budget-199ca)

---

### Comparativo de Autenticação

| Critério | Firebase | Supabase | Auth0 | Clerk |
|---|---|---|---|---|
| MAUs gratuitos | 50.000 | 50.000 | 25.000 | 10.000 |
| Funciona em `github.io` | ⚠️ (problema cookies 3ª parte) | ✅ | ✅ | ⚠️ (focado em React) |
| DB incluído | ❌ (Firestore separado) | ✅ | ❌ | ❌ |
| DX (HTML puro) | ✅ | ✅ | ✅ | ⚠️ (melhor com React) |
| Open source | ❌ | ✅ | ❌ | ❌ |
| Custo a 100k MAUs | ~$750/mês | $25/mês | ~$2.000+/mês | $1.825/mês |
| Inatividade free tier | ❌ (pausa projetos) | ⚠️ (pausa 7 dias) | ✅ | ✅ |

**Recomendação principal:** **Supabase Auth** para a maioria dos cenários de GitHub Pages SaaS — gratuito até 50k MAUs, inclui banco de dados, sem problemas de cookies, e funciona nativamente com domínios `github.io`.

---

## 2. Pagamentos e Assinaturas Recorrentes

### 2.1 Stripe Checkout + Customer Portal

**Funciona com site estático?** ✅ **Sim, com Payment Links e Buy Button.**

O Stripe oferece duas abordagens que não requerem backend para iniciar o checkout:

**Opção A — Stripe Payment Links:**
```html
<!-- Botão de compra gerado no dashboard Stripe — zero backend -->
<a href="https://buy.stripe.com/SEU_LINK" target="_blank">
  Assinar Pro — R$29/mês
</a>
```

**Opção B — Stripe Buy Button (recomendado):**
```html
<script async src="https://js.stripe.com/v3/buy-button.js"></script>
<stripe-buy-button
  buy-button-id="SEU_BUY_BUTTON_ID"
  publishable-key="pk_live_..."
></stripe-buy-button>
```

**Para os webhooks (problema real):** Embora o checkout funcione sem backend, os webhooks de eventos pós-pagamento (ex: `checkout.session.completed`, `customer.subscription.updated`) **precisam de um endpoint HTTP para receber notificações do Stripe**. Isso é resolvido com serverless:

```
Stripe → Webhook → Supabase Edge Function / Cloudflare Worker → Atualiza banco
```

**Eventos essenciais para monitorar:**
- `checkout.session.completed` — pagamento realizado
- `invoice.payment_succeeded` — cobrança recorrente bem-sucedida
- `invoice.payment_failed` — falha na cobrança
- `customer.subscription.created` / `updated` / `deleted`

**Planos e preços Stripe:**
- 2,9% + R$0,30 por transação (cartão nacional)
- +0,5% com cartões internacionais
- +1% para conversão de moeda
- +0,5% para Stripe Tax
- Stripe Billing: gratuito até $100k MRR, depois 0,7% do volume
- **Taxa efetiva internacional: 4,4% – 5,4%** quando incluídos impostos e conversão

**Limitações Brasil:** O Stripe processa pagamentos em BRL, aceita cartões nacionais e tem suporte a **Pix** (via API). Porém, **não suporta boleto bancário** de forma nativa para assinaturas. Para mercado 100% brasileiro com boleto, as alternativas nacionais são melhores.

**Fonte:** [Stripe Checkout Quickstart](https://docs.stripe.com/checkout/quickstart), [Stripe Webhooks Documentation](https://docs.stripe.com/billing/subscriptions/webhooks), [Payment Gateway Integration in Static Sites](https://kinsta.com/blog/payment-gateway-integration/)

---

### 2.2 Paddle

**Modelo:** Merchant of Record (MoR) — o Paddle é juridicamente o vendedor, você recebe o valor líquido.

**Taxa:** 5% + $0,50 por transação (inclui tudo: impostos, câmbio, chargebacks)

**Funciona com site estático?** ✅ **Sim, com Paddle.js overlay.**

```html
<script src="https://cdn.paddle.com/paddle/v2/paddle.js"></script>
<script>
  Paddle.Initialize({ token: 'live_...' });
</script>
<button onclick="Paddle.Checkout.open({ items: [{priceId: 'pri_...', quantity: 1}] })">
  Assinar Pro
</button>
```

**Por que considerar Paddle para o Brasil:**
- Gerencia automaticamente impostos globais (ISS, ICMS para serviços digitais no Brasil, VAT na UE)
- Como MoR, ele é responsável pela conformidade fiscal — você não precisa se preocupar
- Suporte a múltiplas moedas com conversão incluída
- Para SaaS com clientes internacionais, Paddle simplifica enormemente a operação

**Contras:**
- Taxa base mais alta que Stripe (5% + $0,50 vs 2,9% + $0,30)
- **Não suporta Pix ou boleto** — apenas cartões internacionais e carteiras digitais
- Payout semanal com delay de 7-14 dias (Stripe paga em 2 dias)
- Menos customizável que Stripe

**Stripe vs Paddle para Brasil:**

| Critério | Stripe | Paddle |
|---|---|---|
| Taxa base | 2,9% + $0,30 | 5% + $0,50 |
| Taxa efetiva (internacional) | 4,4% – 5,4% | 5% plano |
| Gestão de impostos | Manual (Stripe Tax) | Automática (MoR) |
| Pix | ✅ via API | ❌ |
| Boleto | ❌ | ❌ |
| Chargebacks | Sua responsabilidade | Paddle gerencia |
| Payout | 2 dias | 7–14 dias |
| **Recomendado para** | Clientes BR + dev team | Clientes globais, time pequeno |

**Fonte:** [Stripe vs Paddle 2026 Comparison](https://designrevision.com/blog/stripe-vs-paddle), [Paddle vs Stripe SaaS](https://www.chargeblast.com/blog/paddle-vs-stripe-choosing-the-right-platform-for-saas-payments)

---

### 2.3 Opções Brasileiras: PagSeguro, Hotmart, Mercado Pago

#### PagSeguro (PagBank)

**Adequado para:** SaaS com mercado brasileiro, necessidade de boleto/Pix, clientes sem cartão internacional.

- Suporte a cartão de crédito (parcelas), boleto, Pix, débito automático
- API de assinaturas recorrentes (cobrança automática)
- Checkout transparente (sem redirecionamento)
- Taxas variáveis — geralmente 3,49% para crédito à vista (varia por plano/volume)
- **Limitação:** API menos madura e documentação inferior ao Stripe; suporte técnico mais lento

**Integração com site estático:** Possível via Payment Links do PagSeguro ou API com backend serverless para processar webhooks.

#### Hotmart

**Adequado para:** Infoprodutos, cursos, software com licença anual — **não é ideal para SaaS com planos mensais de baixo ticket.**

- Plataforma de distribuição de produtos digitais com checkout próprio
- Taxa: 9,9% + R$1,00 por transação (para preços acima de R$10)
- Suporte a boleto, cartão, Pix
- **Webhook/API:** Possui webhook nativo para eventos de compra/cancelamento ([documentação](https://developers.hotmart.com/docs/en/tutorials/learn-good-usage-practices/))
- Gerencia o checkout completo — você integra apenas via redirect/link
- **Não recomendado para SaaS recorrente com preços baixos** — taxa alta consome margem

#### Mercado Pago

- Suporte completo a Pix, boleto, cartão (parcelado), carteiras digitais
- API robusta com suporte a assinaturas recorrentes
- Taxa: ~3,49% + R$0,40 para crédito à vista (varia)
- Boa cobertura de métodos de pagamento brasileiros
- Integração mais simples que PagSeguro em alguns casos

#### AbacatePay (emergente, 2025)

- Solução brasileira nova, focada em SaaS
- API moderna com suporte a Pix
- Build in public — boa transparência
- Taxas competitivas para o mercado nacional
- [Documentação AbacatePay](https://dev.to/rayantx/integre-gateway-de-pagamento-ao-seu-saas-como-funciona-quais-os-melhores-e-seus-beneficios-2k54)

---

### 2.4 Contexto de Pagamentos no Brasil (2026)

O ecossistema de pagamentos brasileiro é único e exige atenção especial:

- **Pix** (lançado 2020): Método mais usado por volume de transações. 95% dos adultos já usaram. Custo próximo de zero para o lojista, liquidação instantânea 24/7. Em 2025, o Banco Central lançou **Pix Automático** (débito recorrente com consentimento) — ideal para substituir boleto em assinaturas.
- **Parcelamento sem juros** no cartão: Comportamento esperado pelo consumidor brasileiro (7 em 10 pagam parcelado). Considere oferecer opção de parcelas anuais no plano.
- **Boleto bancário**: Importante para B2B e clientes sem cartão. Pix está gradualmente substituindo.
- **Cartão internacional**: Aprovação reduzida, IOF de até 6,38%, câmbio. Não ideal como método único para clientes BR.

**Estratégia recomendada para SaaS BR:**
1. **Stripe** para clientes internacionais e B2C com cartão
2. **PagSeguro ou Mercado Pago** para clientes BR que preferem boleto/Pix
3. Considerar **Pix Automático** para assinaturas quando estiver amplamente disponível (2026)

**Fonte:** [Brazil's Favorite Payment Methods 2026](https://www.pagbrasil.com/blog/payments/brazils-favorite-payment-method/), [Stripe on Pix Payments](https://stripe.com/resources/more/pix-replacing-cards-cash-brazil)

---

### 2.5 Gerenciar Planos (Free, Pro, Enterprise) com Site Estático

**Padrão recomendado:**

```
1. Usuário faz checkout (Stripe/Paddle/PagSeguro)
   ↓
2. Webhook → Edge Function (Supabase/Cloudflare Workers)
   ↓
3. Edge Function atualiza tabela `subscriptions` no banco (Supabase)
   ↓
4. Frontend lê subscription status no login (via JWT claims ou query)
   ↓
5. Feature flags/acesso controlado pelo plano no frontend
```

**Na prática com Supabase:**

```sql
-- Tabela de subscriptions
CREATE TABLE subscriptions (
  user_id uuid REFERENCES auth.users,
  plan varchar DEFAULT 'free', -- 'free', 'pro', 'enterprise'
  stripe_customer_id varchar,
  stripe_subscription_id varchar,
  current_period_end timestamp,
  status varchar DEFAULT 'active'
);

-- RLS: usuário só acessa própria subscription
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can read own subscription"
  ON subscriptions FOR SELECT
  USING (auth.uid() = user_id);
```

---

### 2.6 Webhooks sem Backend Próprio

**Opção 1 — Supabase Edge Functions** (recomendada):
```typescript
// supabase/functions/stripe-webhook/index.ts
import Stripe from 'npm:stripe'
import { createClient } from 'npm:@supabase/supabase-js'

Deno.serve(async (req) => {
  const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY')!)
  const signature = req.headers.get('stripe-signature')!
  const body = await req.text()
  
  const event = stripe.webhooks.constructEvent(
    body, signature, Deno.env.get('STRIPE_WEBHOOK_SECRET')!
  )
  
  if (event.type === 'checkout.session.completed') {
    // Atualiza subscription no banco
  }
  
  return new Response('ok', { status: 200 })
})
```
- **Limites free:** 500.000 invocações/mês, 150ms CPU por invocação
- URL do webhook: `https://SEU_PROJETO.supabase.co/functions/v1/stripe-webhook`
- **Atenção PagSeguro/Asaas:** Cloudflare (que protege o Supabase) pode bloquear webhooks de gateways brasileiros com User-Agent incomum. Use Cloudflare Workers como proxy intermediário nesses casos.

**Opção 2 — Cloudflare Workers** (alternativa, mais controle):
- Free: 100.000 requisições/dia, 10ms CPU por req
- Paid: $5/mês por 10M requisições/mês
- Zero cold start, 300+ edge locations
- [Preços Cloudflare Workers](https://developers.cloudflare.com/workers/platform/pricing/)

**Opção 3 — Vercel Edge Functions:**
- Free: 1M invocações/mês (no hobby plan)
- Excelente integração com Next.js

---

## 3. GitHub Actions como Cron Jobs para Atualização de Dados

### 3.1 Como Funciona

O GitHub Actions suporta triggers agendados via sintaxe cron:

```yaml
# .github/workflows/update-data.yml
name: Atualizar dados da API
on:
  schedule:
    - cron: '0 */6 * * *'  # A cada 6 horas
  workflow_dispatch:  # Permite execução manual

jobs:
  update:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Buscar dados da API
        run: |
          curl -H "Authorization: Bearer ${{ secrets.API_KEY }}" \
            "https://api.exemplo.com/dados" \
            -o data/dados.json
      
      - name: Commit e push dos dados atualizados
        run: |
          git config --local user.email "action@github.com"
          git config --local user.name "GitHub Action"
          git add data/dados.json
          git diff --quiet && git diff --staged --quiet || \
            git commit -m "chore: atualiza dados [skip ci]"
          git push
```

**O commit aciona automaticamente o rebuild do GitHub Pages**, atualizando o site com os dados novos.

---

### 3.2 Limites do GitHub Actions (2026)

| Recurso | Free (Público) | Free (Privado) | Pro | Team |
|---|---|---|---|---|
| Minutos/mês | **Ilimitado** | 2.000 min/mês | 3.000 min/mês | 50.000 min/mês |
| Frequência mínima cron | 5 minutos | 5 minutos | 5 minutos | 5 minutos |
| Delay real | 5–15 min | 5–15 min | 5–15 min | Varia |
| Inatividade | Desativa em **60 dias** | 60 dias | N/A | N/A |

**Regras críticas:**
1. **Frequência mínima:** 5 minutos (`*/5 * * * *`). Tentar usar `* * * * *` resulta em execuções a cada 5 min.
2. **Delay em horários de pico:** GitHub não garante precisão. Crons agendados no início da hora (ex: `0 * * * *`) têm maior delay. Prefira `*/15 * * * *` ou horários off-peak.
3. **Suspensão por inatividade:** Repositórios públicos sem commit há 60 dias têm crons suspensos automaticamente.
4. **Repos públicos gratuitos:** Minutos são ilimitados — ideal para SaaS em GitHub Pages.

**Workaround para suspensão (60 dias):** Use a action [keepalive-workflow](https://github.com/marketplace/actions/keepalive-workflow):

```yaml
# Adicione como último step nos seus cron jobs
- uses: gautamkrishnar/keepalive-workflow@v2
```

Isso usa a API do GitHub para re-habilitar workflows antes dos 60 dias, sem criar commits dummy.

**Fonte:** [GitHub Actions Scheduled Jobs Frequency](https://github.blog/changelog/2019-11-01-github-actions-scheduled-jobs-maximum-frequency-is-changing/), [GitHub Pricing](https://github.com/pricing), [Keepalive Workflow Action](https://github.com/marketplace/actions/keepalive-workflow)

---

### 3.3 Estratégias: Tempo Real vs Batch

| Abordagem | Mecanismo | Frequência Mínima | Latência | Custo |
|---|---|---|---|---|
| **Batch (GitHub Actions)** | Cron no workflow | 5 minutos | 5–15 min | Gratuito (repos públicos) |
| **Quasi-real-time** | Polling client-side | Por requisição do usuário | Segundos | Custo da API externa |
| **Real-time (push)** | WebSockets/SSE | N/A | Milissegundos | Supabase Realtime (free: 200 conexões) |
| **Webhook-driven** | Terceiro → BaaS Function | Por evento | Segundos | Supabase Functions |

**Quando usar cada um:**
- **Batch com GitHub Actions:** Dados que mudam poucas vezes por hora/dia (ex: rankings, preços de fechamento, clima). Ideal para dados do tipo "atualização diária".
- **Polling client-side:** Dados que mudam com frequência e são gratuitos (ex: cotações públicas). O frontend busca direto na API a cada X minutos.
- **Supabase Realtime:** Colaboração em tempo real entre usuários (ex: edição colaborativa). Usa WebSockets gerenciados.
- **Webhook-driven:** Eventos externos (pagamento confirmado, email aberto). O terceiro chama sua Edge Function.

---

### 3.4 Onde Armazenar Dados Atualizados

**Opção A — JSON no próprio repositório (mais simples):**
- GitHub Actions busca dados → salva em `data/dados.json` → commita → Pages rebuild
- Dados ficam no repo Git (histórico, auditável)
- Limite prático: arquivos < 50 MB (GitHub bloqueia >100 MB)
- Rebuild do Pages leva 1–5 minutos após o commit

**Opção B — Cloudflare R2 (recomendado para dados grandes):**
- R2 free: 10 GB/mês storage, 1M operações/mês Class A, 10M Class B, **sem taxa de egress**
- GitHub Actions faz upload para R2 usando AWS S3 API compatível:

```yaml
- name: Upload para Cloudflare R2
  run: |
    pip install awscli
    aws s3 cp dados.json s3://MEU_BUCKET/dados.json \
      --endpoint-url https://${{ secrets.CF_ACCOUNT_ID }}.r2.cloudflarestorage.com
  env:
    AWS_ACCESS_KEY_ID: ${{ secrets.CF_ACCESS_KEY_ID }}
    AWS_SECRET_ACCESS_KEY: ${{ secrets.CF_SECRET_KEY }}
```

- Frontend busca diretamente do URL público do R2 (ou via Cloudflare CDN)

**Opção C — Supabase Database/Storage:**
- GitHub Actions → script Python/Node → insere no banco Supabase via API
- Frontend busca via Supabase SDK (query SQL, RLS, cache)
- Melhor opção quando os dados precisam de filtragem/query complexa

**Opção D — GitHub Pages com dados embutidos:**
- Build process que gera HTML/JS com dados já incluídos no bundle
- Zero latência de fetch para o usuário (dados estão no HTML)
- Adequado para dados que não mudam muito

---

## 4. Arquitetura Jamstack SaaS em Site Estático

### 4.1 O Padrão "Jamstack SaaS"

```
┌─────────────────────────────────────────────────────┐
│                   GITHUB PAGES                      │
│         (HTML + CSS + JS estático, CDN global)      │
│                                                     │
│  ┌─────────────────┐    ┌────────────────────────┐  │
│  │   Login/Auth    │    │  Dashboard/App Logic   │  │
│  │  (Supabase/     │    │  (React/Vanilla JS,    │  │
│  │   Firebase)     │    │   feature flags)       │  │
│  └────────┬────────┘    └───────────┬────────────┘  │
└───────────┼────────────────────────┼───────────────┘
            │                        │
            ▼                        ▼
┌───────────────────┐    ┌────────────────────────┐
│   SUPABASE        │    │   STRIPE / PADDLE      │
│ - Auth (JWT)      │    │ - Checkout (static)    │
│ - PostgreSQL DB   │    │ - Customer Portal      │
│ - Storage (1GB)   │    │ - Webhooks → Edge Fn   │
│ - Edge Functions  │    └────────────────────────┘
│ - Realtime        │
└───────────────────┘
            │
            ▼
┌───────────────────┐    ┌────────────────────────┐
│ GITHUB ACTIONS    │    │  CLOUDFLARE (opcional) │
│ - Cron jobs       │    │ - Workers (webhooks)   │
│ - Fetch APIs      │    │ - R2 (dados grandes)   │
│ - Update data     │    │ - KV (cache)           │
└───────────────────┘    └────────────────────────┘
```

### 4.2 Padrões que Funcionam em Jamstack SaaS

**Padrão 1: Auth Token → Feature Gate**
```javascript
// Ao login, busca subscription do usuário
const { data: user } = await supabase.auth.getUser()
const { data: sub } = await supabase
  .from('subscriptions')
  .select('plan, current_period_end')
  .eq('user_id', user.id)
  .single()

// Feature gate no frontend
const isPro = sub?.plan === 'pro' && new Date(sub.current_period_end) > new Date()

// Renderiza condicionalmente
if (isPro) {
  document.getElementById('pro-feature').style.display = 'block'
} else {
  document.getElementById('upgrade-cta').style.display = 'block'
}
```

**Padrão 2: Soft vs Hard Gate**
- **Soft gate:** Feature visível mas desabilitada (botão cinza + tooltip "Upgrade para Pro")
- **Hard gate:** Feature completamente oculta para usuários free
- Para SaaS, **soft gates** costumam converter melhor (usuário vê o que pode ter)

**Padrão 3: Client-Side Security vs Server-Side Security**
- **Frontend (JavaScript):** Pode ocultar UI, mas NÃO é seguro para dados sensíveis
- **Supabase RLS:** Segurança real — mesmo que usuário manipule JS, RLS impede acesso aos dados
- Sempre combine: UI gates para UX + RLS para segurança real

---

### 4.3 BaaS que Complementam GitHub Pages

| BaaS | Gratuito | Use case principal | Integração |
|---|---|---|---|
| **Supabase** | 500MB DB, 1GB storage, 50k MAUs | Full-stack BaaS (DB + Auth + Storage + Functions) | `@supabase/supabase-js` |
| **Firebase** | Spark: Firestore, Auth, Storage | Apps mobile-first, realtime | `firebase` SDK |
| **PlanetScale** | 5GB DB (MySQL) | Banco de dados apenas | SQL via fetch API |
| **Neon** | 512MB PostgreSQL | Banco serverless | SQL via fetch |
| **Cloudflare D1** | 5GB SQLite | DB + Workers | Cloudflare Workers |
| **Cloudflare R2** | 10GB storage, sem egress | Storage de arquivos/dados | S3-compatible API |
| **Cloudflare KV** | 1GB, 100k reads/day | Cache, config, feature flags | Workers binding |
| **Upstash Redis** | 10k comandos/dia | Rate limiting, cache, contadores | HTTP API |
| **Resend/SendGrid** | 3k/mês emails | Transactional emails | HTTP API |

---

### 4.4 Feature Flags para Controle de Planos

**Abordagem simples (sem serviço externo):**

```javascript
// feature-flags.js — carregado no login
async function loadUserFlags(userId) {
  const { data: sub } = await supabase
    .from('subscriptions')
    .select('plan')
    .eq('user_id', userId)
    .single()
  
  const plan = sub?.plan || 'free'
  
  return {
    // Free
    basic_dashboard: true,
    export_csv_limited: true,
    
    // Pro
    unlimited_exports: plan !== 'free',
    api_access: plan !== 'free',
    team_members: plan !== 'free',
    advanced_analytics: plan !== 'free',
    
    // Enterprise
    sso_login: plan === 'enterprise',
    custom_domain: plan === 'enterprise',
    audit_logs: plan === 'enterprise',
    priority_support: plan === 'enterprise',
  }
}
```

**Ferramentas de Feature Flags (para escala):**

| Ferramenta | Free Tier | Melhor para |
|---|---|---|
| **PostHog** | 1M eventos/mês | Analytics + Feature flags unificado |
| **Statsig** | 5M eventos/mês | A/B testing + feature gates |
| **GrowthBook** | Open source (self-host) | Controle total, sem lock-in |
| **Unleash** | Open source (self-host) | Enterprise features open source |
| **LaunchDarkly** | Pago (~$12/mês) | Enterprise governance |
| **Supabase custom** | Incluído no Supabase | Simples, sem serviço extra |

**Regra de segurança:** Feature flags no frontend servem para UX. Para segurança real (proteção de dados, chamadas de API), use Supabase RLS ou validação na Edge Function. Um usuário pode inspecionar e modificar o JavaScript do frontend.

**Fonte:** [SaaS Feature Flags Guide 2026](https://designrevision.com/blog/blog/saas-feature-flags-guide), [Feature Flags at Scale - Statsig](https://www.statsig.com/perspectives/implementing-feature-flags-at-scale)

---

### 4.5 Rate Limiting e Proteção de APIs

**Sem backend próprio, as opções são:**

**Opção 1 — Rate limiting via Supabase RLS + counters:**
```sql
-- Tabela de uso de API
CREATE TABLE api_usage (
  user_id uuid REFERENCES auth.users,
  endpoint varchar,
  requests_count integer DEFAULT 0,
  window_start timestamp DEFAULT now()
);

-- Função para verificar rate limit
CREATE OR REPLACE FUNCTION check_rate_limit(p_user_id uuid, p_limit integer)
RETURNS boolean AS $$
DECLARE
  current_count integer;
BEGIN
  SELECT requests_count INTO current_count
  FROM api_usage
  WHERE user_id = p_user_id
    AND window_start > now() - interval '1 hour';
  
  RETURN COALESCE(current_count, 0) < p_limit;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
```

**Opção 2 — Cloudflare Workers (mais robusto):**
- Cloudflare oferece rate limiting nativo via Workers
- Pode usar Cloudflare KV para contar requisições por usuário
- Free: 100k requisições/dia

**Opção 3 — Upstash Rate Limiting (mais simples):**
```javascript
// Edge Function com rate limiting via Upstash Redis
import { Ratelimit } from "@upstash/ratelimit"
import { Redis } from "@upstash/redis"

const ratelimit = new Ratelimit({
  redis: Redis.fromEnv(),
  limiter: Ratelimit.slidingWindow(10, "10 s"), // 10 req/10s
})

const { success } = await ratelimit.limit(userId)
if (!success) {
  return new Response("Rate limit exceeded", { status: 429 })
}
```

**Proteção de chaves de API no frontend:**
- **NUNCA exponha chaves secretas no JavaScript do browser**
- Chaves públicas (Stripe publishable key, Supabase anon key) são seguras
- Chaves secretas devem estar apenas em Edge Functions/Supabase Secrets

---

## 5. Resumo Executivo e Stack Recomendado

### Stack Mínimo para SaaS em GitHub Pages

```
Frontend: GitHub Pages (HTML/JS/CSS ou React bundle estático)
Auth:      Supabase Auth (50k MAUs gratuitos, sem problema de cookies)
Banco:     Supabase PostgreSQL (500MB gratuitos, RLS nativo)
Storage:   Supabase Storage (1GB) ou Cloudflare R2 (10GB, sem egress)
Pagamento: Stripe Checkout/Payment Links (+ Supabase Edge Function para webhooks)
Cron:      GitHub Actions (gratuito em repos públicos)
Workers:   Supabase Edge Functions ou Cloudflare Workers
```

**Custo total para MVP (< 1.000 usuários pagantes):**
- GitHub Pages: **Gratuito**
- Supabase (free tier): **Gratuito**
- Stripe: **0% setup, apenas por transação (2,9% + $0,30)**
- Cloudflare Workers: **Gratuito** (até 100k req/dia)
- GitHub Actions: **Gratuito** (repo público)
- **Total fixo mensal: $0** + taxa por transação

### Para Mercado Brasileiro:
```
Pagamento BR: PagSeguro ou Mercado Pago (Pix + boleto + parcelas)
Pagamento Global: Stripe
Ou: Stripe para tudo (suporte a Pix via API desde 2024)
```

### Decision Tree — Escolha de Auth:

```
Tem domínio customizado?
├── Sim → Firebase Auth ou Supabase Auth (ambos funcionam)
└── Não (usando github.io)
    ├── Usa React/Next.js? → Clerk (melhor DX, 10k MAUs free)
    └── HTML puro ou precisa de DB? → Supabase Auth (melhor custo/benefício)
```

### Decision Tree — Escolha de Pagamento:

```
Clientes são principalmente brasileiros?
├── Sim → PagSeguro / Mercado Pago + Stripe (para quem pagar com cartão)
└── Não (global ou maioria internacional)
    ├── Time pequeno, quer simplicidade fiscal? → Paddle (5% + tudo incluso)
    └── Quer controle e menor taxa base? → Stripe (2,9% + configura Stripe Tax)
```

---

## 6. Referências e Fontes

- [Firebase Auth - GitHub Authentication](https://firebase.google.com/docs/auth/web/github-auth)
- [Firebase Auth - Third-Party Cookies Issue](https://github.com/firebase/firebase-js-sdk/issues/934)
- [Supabase Auth Documentation](https://supabase.com/docs/guides/auth)
- [Supabase Pricing 2026 Guide](https://uibakery.io/blog/supabase-pricing)
- [Supabase Free Tier Limits 2026](https://www.metacto.com/blogs/the-true-cost-of-supabase-a-comprehensive-guide-to-pricing-integration-and-maintenance)
- [Supabase Edge Functions Limits](https://supabase.com/docs/guides/functions/limits)
- [Auth0 Pricing](https://auth0.com/pricing)
- [Clerk Pricing Guide](https://supertokens.com/blog/clerk-pricing-the-complete-guide)
- [Clerk vs Supabase Auth Comparison](https://www.getmonetizely.com/articles/clerk-vs-supabase-auth-how-to-choose-the-right-authentication-service-for-your-budget-199ca)
- [Stripe Checkout with Static Sites](https://kinsta.com/blog/payment-gateway-integration/)
- [Stripe Webhooks for Subscriptions](https://docs.stripe.com/billing/subscriptions/webhooks)
- [Stripe vs Paddle 2026](https://designrevision.com/blog/stripe-vs-paddle)
- [Paddle vs Stripe - Chargeblast](https://www.chargeblast.com/blog/paddle-vs-stripe-choosing-the-right-platform-for-saas-payments)
- [Stripe on Pix Payments Brazil](https://stripe.com/resources/more/pix-replacing-cards-cash-brazil)
- [Brazil Payment Methods 2026](https://www.pagbrasil.com/blog/payments/brazils-favorite-payment-method/)
- [Gateway de Pagamento para SaaS Brasil](https://dev.to/rayantx/integre-gateway-de-pagamento-ao-seu-saas-como-funciona-quais-os-melhores-e-seus-beneficios-2k54)
- [Hotmart Webhook Documentation](https://help.hotmart.com/en/article/360001491352/)
- [GitHub Actions Cron Minimum Frequency](https://github.blog/changelog/2019-11-01-github-actions-scheduled-jobs-maximum-frequency-is-changing/)
- [GitHub Pricing - Actions Minutes](https://github.com/pricing)
- [GitHub Actions Pricing Changes 2026](https://github.com/resources/insights/2026-pricing-changes-for-github-actions)
- [Using GitHub Actions + Pages for Dynamic Data](https://aaronsaray.com/2021/github-actions-pages-scheduled-data-updates/)
- [GitHub Actions Cron - 60 Day Inactivity](https://stackoverflow.com/questions/67184368/prevent-scheduled-github-actions-from-becoming-disabled)
- [Keepalive Workflow Action](https://github.com/marketplace/actions/keepalive-workflow)
- [Cloudflare Workers Pricing](https://developers.cloudflare.com/workers/platform/pricing/)
- [Cloudflare R2 GitHub Actions Integration](https://mzfit.app/blog/github_with_cloudflare_r2/)
- [SaaS Feature Flags Guide 2026](https://designrevision.com/blog/saas-feature-flags-guide)
- [Feature Flags at Scale - Statsig](https://www.statsig.com/perspectives/implementing-feature-flags-at-scale)
- [Jamstack Architecture 2026](https://www.linkedin.com/pulse/jamstack-high-performance-web-apps-xgxpc)
- [SaaS Tech Stack Guide 2025](https://brights.io/blog/saas-technology-stack)
- [No-Build Static Site with Supabase](https://willschenk.com/howto/2024/no_build_static_site_that_used_supabase/)
- [Stripe Webhooks Serverless SaaS](https://scaletozeroaws.com/blog/stripe-webhooks-serverless-saas)
- [Supabase + Stripe Webhook Handler](https://github.com/firebase/firebase-js-sdk/issues/987)
